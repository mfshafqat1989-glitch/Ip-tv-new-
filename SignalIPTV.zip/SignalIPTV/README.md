# Signal TV 2.0 – free IPTV player for Android phones and Android TV

Features: M3U links and files, Xtream Codes login, Live TV / Movies / Series,
TV guide (EPG) with now/next, favorites, recently watched, resume movies,
search, multiple playlists, parental PIN with hidden categories, custom user agent,
native video player (HLS, TS, MP4, MKV), Android TV remote and launcher support.

Build: the GitHub workflow unzips SignalIPTV.zip and builds app-debug.apk.
