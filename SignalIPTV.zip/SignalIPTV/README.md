# Signal TV – free IPTV player for Android

Build the APK with GitHub (free, nothing to install):

1. Sign in at github.com and create a new repository (any name).
2. Choose "uploading an existing file" and drag in everything from this folder,
   including the hidden .github folder (easiest from a computer).
3. Commit. Open the "Actions" tab and wait about 3-5 minutes for "Build APK" to finish.
4. Open the finished run, download "SignalTV-apk", unzip it, and install app-debug.apk
   on your phone (allow "Install unknown apps" when asked).

Or open this folder in Android Studio and choose Build > Build APK(s).
