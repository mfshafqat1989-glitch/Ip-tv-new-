package com.signal.iptv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer;
import androidx.media3.decoder.ffmpeg.FfmpegLibrary;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.audio.AudioRendererEventListener;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class PlayerActivity extends Activity {
    /** The list being played. Set by MainActivity just before this screen opens. */
    static JSONArray items = new JSONArray();

    private ExoPlayer player;
    private PlayerView view;
    private TextView info;
    private TextView digitsView;
    private LinearLayout topBar;
    private int index;
    private boolean live;
    private boolean retried;
    private boolean controlsVisible;
    private int resizeMode = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder digits = new StringBuilder();
    private final Runnable hideInfo = () -> { if (info != null) info.setVisibility(View.GONE); };
    private final Runnable jump = this::jumpToDigits;
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm", Locale.getDefault());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (items == null || items.length() == 0) {
            finish();
            return;
        }
        Intent in = getIntent();
        index = in.getIntExtra("index", 0);
        if (index < 0 || index >= items.length()) index = 0;
        live = in.getBooleanExtra("live", false);
        long start = in.getLongExtra("position", 0);
        String ua = in.getStringExtra("ua");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        view = new PlayerView(this);
        root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        info = new TextView(this);
        info.setTextColor(0xFFE8EBF2);
        info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        info.setBackgroundColor(0xDD0B1328);
        info.setPadding(dp(18), dp(12), dp(18), dp(12));
        info.setMaxWidth(dp(560));
        info.setVisibility(View.GONE);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        ilp.setMargins(dp(24), dp(24), dp(24), dp(24));
        root.addView(info, ilp);

        digitsView = new TextView(this);
        digitsView.setTextColor(0xFFFCA311);
        digitsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 56);
        digitsView.setTypeface(Typeface.DEFAULT_BOLD);
        digitsView.setShadowLayer(12, 0, 2, Color.BLACK);
        digitsView.setVisibility(View.GONE);
        root.addView(digitsView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setVisibility(View.GONE);
        if (live) {
            topBar.addView(button("Prev", v -> switchChannel(-1)));
            topBar.addView(button("Next", v -> switchChannel(1)));
        }
        topBar.addView(button("Aspect", v -> cycleAspect()));
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        tlp.setMargins(dp(12), dp(12), dp(12), dp(12));
        root.addView(topBar, tlp);
        setContentView(root);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        if (ua != null && !ua.isEmpty()) http.setUserAgent(ua);
        DefaultDataSource.Factory data = new DefaultDataSource.Factory(this, http);
        // The device's own decoders play everything they can. The built-in audio decoder is added
        // last, only as a backup for sound formats (AC3, E-AC3, MP2, DTS) the device can't play.
        // No built-in video decoder is used.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this) {
            @Override
            protected void buildAudioRenderers(Context context, int extensionRendererMode,
                    MediaCodecSelector mediaCodecSelector, boolean enableDecoderFallback, AudioSink audioSink,
                    Handler eventHandler, AudioRendererEventListener eventListener, ArrayList<Renderer> out) {
                super.buildAudioRenderers(context, extensionRendererMode, mediaCodecSelector,
                        enableDecoderFallback, audioSink, eventHandler, eventListener, out);
                try {
                    if (FfmpegLibrary.isAvailable()) {
                        out.add(new FfmpegAudioRenderer(eventHandler, eventListener, audioSink));
                    }
                } catch (Throwable ignored) {
                    // Backup decoder not usable on this device; the device's own decoders still work.
                }
            }
        };
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);
        renderers.setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(data))
                .build();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        player.setVolume(1f);
        view.setPlayer(player);
        view.setKeepScreenOn(true);
        view.setControllerShowTimeoutMs(4000);
        view.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility -> {
            controlsVisible = visibility == View.VISIBLE;
            topBar.setVisibility(visibility);
        });
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (!retried) {
                    retried = true;
                    String url = current().optString("url", "");
                    load(index, live ? 0 : player.getCurrentPosition(), !url.toLowerCase(Locale.ROOT).contains(".m3u8"));
                    return;
                }
                showInfo(current().optString("name", "") + "\nThis stream didn't play (" + error.getErrorCodeName()
                        + "). It may be offline or blocked by the provider.", 9000);
            }

            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) retried = false;
                if (state == Player.STATE_ENDED && !live && index + 1 < items.length()) {
                    load(index + 1, 0, false);
                }
            }
        });
        load(index, start, false);
        view.requestFocus();
    }

    private JSONObject current() {
        JSONObject o = items.optJSONObject(index);
        return o != null ? o : new JSONObject();
    }

    private void load(int i, long position, boolean forceHls) {
        try {
            loadUnsafe(i, position, forceHls);
        } catch (Throwable t) {
            showInfo("Couldn't start this stream (" + t.getClass().getSimpleName() + "). Try another channel.", 8000);
        }
    }

    private void loadUnsafe(int i, long position, boolean forceHls) {
        JSONObject it = items.optJSONObject(i);
        if (it == null) return;
        index = i;
        MediaItem.Builder b = new MediaItem.Builder().setUri(Uri.parse(it.optString("url", "")));
        if (forceHls) b.setMimeType(MimeTypes.APPLICATION_M3U8);
        if (position > 0) player.setMediaItem(b.build(), position);
        else player.setMediaItem(b.build());
        player.prepare();
        player.setPlayWhenReady(true);
        showChannelInfo();
    }

    private void switchChannel(int delta) {
        if (!live) return;
        int n = items.length();
        retried = false;
        load(((index + delta) % n + n) % n, 0, false);
    }

    private void jumpToDigits() {
        digitsView.setVisibility(View.GONE);
        if (digits.length() == 0) return;
        int want;
        try {
            want = Integer.parseInt(digits.toString());
        } catch (NumberFormatException e) {
            want = -1;
        }
        digits.setLength(0);
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o != null && o.optInt("num", -2) == want) {
                retried = false;
                load(i, 0, false);
                return;
            }
        }
        showInfo("No channel " + want + " in this list", 2500);
    }

    private void showChannelInfo() {
        JSONObject it = current();
        StringBuilder sb = new StringBuilder();
        int num = it.optInt("num", 0);
        if (live && num > 0) sb.append(num).append("   ");
        sb.append(it.optString("name", ""));
        JSONArray epg = it.optJSONArray("epg");
        if (epg != null) {
            long now = System.currentTimeMillis();
            int shown = 0;
            for (int i = 0; i < epg.length() && shown < 2; i++) {
                JSONArray p = epg.optJSONArray(i);
                if (p == null) continue;
                long s = p.optLong(0), e = p.optLong(1);
                if (e <= now) continue;
                String label = (s <= now) ? "Now  " : "Next  ";
                sb.append("\n").append(label).append(clock.format(new Date(s))).append("  ").append(p.optString(2, ""));
                shown++;
            }
        }
        showInfo(sb.toString(), live ? 5000 : 3000);
    }

    private void showInfo(String text, long ms) {
        info.setText(text);
        info.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideInfo);
        handler.postDelayed(hideInfo, ms);
    }

    private void cycleAspect() {
        resizeMode = (resizeMode + 1) % 3;
        int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
        String[] names = {"Fit", "Stretch", "Zoom"};
        view.setResizeMode(modes[resizeMode]);
        showInfo("Picture: " + names[resizeMode], 1500);
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setFocusable(false);
        b.setOnClickListener(l);
        return b;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (code == KeyEvent.KEYCODE_BACK) {
            if (!down) {
                if (controlsVisible) view.hideController();
                else finishWithResult();
            }
            return true;
        }
        if (live) {
            boolean upKey = code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_UP
                    || (code == KeyEvent.KEYCODE_DPAD_UP && !controlsVisible);
            boolean downKey = code == KeyEvent.KEYCODE_CHANNEL_DOWN || code == KeyEvent.KEYCODE_PAGE_DOWN
                    || (code == KeyEvent.KEYCODE_DPAD_DOWN && !controlsVisible);
            if (upKey || downKey) {
                if (down && e.getRepeatCount() == 0) switchChannel(upKey ? 1 : -1);
                return true;
            }
            if (code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
                if (down) {
                    if (digits.length() < 4) digits.append((char) ('0' + (code - KeyEvent.KEYCODE_0)));
                    digitsView.setText(digits.toString());
                    digitsView.setVisibility(View.VISIBLE);
                    handler.removeCallbacks(jump);
                    handler.postDelayed(jump, 1500);
                }
                return true;
            }
        }
        if (code == KeyEvent.KEYCODE_INFO || code == KeyEvent.KEYCODE_GUIDE) {
            if (down) showChannelInfo();
            return true;
        }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_PROG_YELLOW) {
            if (down) cycleAspect();
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        finishWithResult();
    }

    private void finishWithResult() {
        Intent r = new Intent();
        r.putExtra("index", index);
        if (player != null && !live) {
            r.putExtra("position", Math.max(0, player.getCurrentPosition()));
            r.putExtra("duration", Math.max(0, player.getDuration()));
        } else {
            r.putExtra("position", -1L);
            r.putExtra("duration", 0L);
        }
        setResult(RESULT_OK, r);
        finish();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
