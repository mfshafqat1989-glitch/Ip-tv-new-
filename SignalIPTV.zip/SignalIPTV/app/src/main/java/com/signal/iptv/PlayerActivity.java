package com.signal.iptv;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer;
import androidx.media3.decoder.ffmpeg.FfmpegLibrary;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.Renderer;
import androidx.media3.exoplayer.audio.AudioRendererEventListener;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Full-screen player: vibrant overlay, audio/subtitle choice, channel/episode lists, speed, picture size. */
public class PlayerActivity extends Activity {
    /** The list being played. Set by MainActivity just before this screen opens. */
    static JSONArray items = new JSONArray();

    private static final int CORAL = 0xFFFF4D6D;
    private static final int AMBER = 0xFFFCA311;
    private static final int NAVY = 0xFF14213D;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int MUTED = 0xFFC9D1E3;
    private static final int PANEL = 0xF20E1222;
    private static final float[] SPEEDS = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};

    private ExoPlayer player;
    private PlayerView view;
    private FrameLayout root;
    private LinearLayout top, bottom, panel, seasonRow, nextCard;
    private HorizontalScrollView seasonScroll;
    private TextView liveBadge, kicker, title, subtitle, clockView, posText, durText, nowText, nextText;
    private TextView digitsView, msgView, panelTitle, nextTitle, nextCount, playBtn, speedBtn, aspectBtn, nextPlay;
    private SeekBar seek;
    private ProgressBar spinner, epgBar;
    private ListView panelList;
    private PanelAdapter adapter;
    private int index;
    private boolean live, series;
    private boolean retried, overlayShown, panelShown, userSeeking;
    private int resizeMode = 0, speedIdx = 2, countdown = 0, panelCurrent = -1;
    private String panelMode = "";
    private String season;
    // Phone-only touch features (never used on TV boxes)
    private boolean touch;
    private LinearLayout center, brightBox;
    private View brightFill;
    private TextView brightPct, seekHint;
    private boolean swipeBright;
    private float startBright;
    private long lastSeekTap;
    private int seekSide, seekAccum;
    private final Runnable hideBright = () -> { if (brightBox != null) brightBox.setVisibility(View.GONE); };
    private final Runnable hideSeekHint = () -> { if (seekHint != null) seekHint.setVisibility(View.GONE); };
    private final List<String[]> rows = new ArrayList<>();
    private final List<Object> refs = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder digits = new StringBuilder();
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm", Locale.getDefault());
    private final Runnable autoHide = this::hideOverlay;
    private final Runnable jump = this::jumpToDigits;
    private final Runnable hideMsg = () -> { if (msgView != null) msgView.setVisibility(View.GONE); };
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            handler.postDelayed(this, 1000);
        }
    };
    private final Runnable countdownTick = new Runnable() {
        @Override
        public void run() {
            if (countdown <= 0) {
                playNext();
                return;
            }
            nextCount.setText("Next episode in " + countdown);
            countdown--;
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (items == null || items.length() == 0) {
            finish();
            return;
        }
        Intent in = getIntent();
        index = in.getIntExtra("index", 0);
        if (index < 0 || index >= items.length()) index = 0;
        live = in.getBooleanExtra("live", false);
        String kind = in.getStringExtra("kind");
        series = "series".equals(kind);
        long start = in.getLongExtra("position", 0);
        String ua = in.getStringExtra("ua");

        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        boolean tvDevice = (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback")
                || !getPackageManager().hasSystemFeature("android.hardware.touchscreen");
        touch = !tvDevice;

        buildUi();
        buildPlayer(ua);
        load(index, start, false);
        handler.post(tick);
    }

    // ---------------------------------------------------------------- layout

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);

        view = new PlayerView(this);
        view.setUseController(false);
        view.setKeepContentOnPlayerReset(true);
        view.setShutterBackgroundColor(Color.TRANSPARENT);
        view.setOnClickListener(v -> {
            if (panelShown) hidePanel();
            else if (overlayShown) hideOverlay();
            else showOverlay(false);
        });
        root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        spinner = new ProgressBar(this, null, android.R.attr.progressBarStyleLarge);
        spinner.setIndeterminateTintList(ColorStateList.valueOf(CORAL));
        spinner.setVisibility(View.GONE);
        root.addView(spinner, new FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER));

        // top: what's playing
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(28), dp(22), dp(28), dp(56));
        top.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xD9000000, 0x00000000}));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        LinearLayout kickRow = new LinearLayout(this);
        kickRow.setOrientation(LinearLayout.HORIZONTAL);
        kickRow.setGravity(Gravity.CENTER_VERTICAL);
        liveBadge = text(12, true, WHITE);
        liveBadge.setText("LIVE");
        liveBadge.setPadding(dp(8), dp(2), dp(8), dp(2));
        liveBadge.setBackground(rounded(CORAL, dp(5)));
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lbp.setMargins(0, 0, dp(10), 0);
        kickRow.addView(liveBadge, lbp);
        kicker = text(13, true, AMBER);
        kickRow.addView(kicker);
        texts.addView(kickRow);
        title = text(30, true, WHITE);
        texts.addView(title);
        subtitle = text(16, false, MUTED);
        texts.addView(subtitle);
        top.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        clockView = text(20, true, WHITE);
        top.addView(clockView);
        root.addView(top, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // bottom: progress + controls
        bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setPadding(dp(28), dp(64), dp(28), dp(22));
        bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xEB000000, 0x00000000}));
        if (live) {
            nowText = text(18, true, WHITE);
            bottom.addView(nowText);
            epgBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            epgBar.setMax(1000);
            epgBar.setProgressTintList(ColorStateList.valueOf(CORAL));
            epgBar.setProgressBackgroundTintList(ColorStateList.valueOf(0x40FFFFFF));
            LinearLayout.LayoutParams ebp = new LinearLayout.LayoutParams(dp(420), dp(6));
            ebp.setMargins(0, dp(6), 0, dp(6));
            bottom.addView(epgBar, ebp);
            nextText = text(14, false, MUTED);
            bottom.addView(nextText);
        } else {
            LinearLayout seekRow = new LinearLayout(this);
            seekRow.setOrientation(LinearLayout.HORIZONTAL);
            seekRow.setGravity(Gravity.CENTER_VERTICAL);
            posText = text(15, true, WHITE);
            seekRow.addView(posText);
            seek = new SeekBar(this);
            seek.setProgressTintList(ColorStateList.valueOf(CORAL));
            seek.setThumbTintList(ColorStateList.valueOf(WHITE));
            seek.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
            seek.setKeyProgressIncrement(10);
            seek.setBackground(states(0x00000000, 0x33FFFFFF, dp(8)));
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                    if (!fromUser) return;
                    posText.setText(fmt(progress * 1000L));
                    if (!userSeeking) player.seekTo(progress * 1000L);
                    scheduleHide();
                }

                @Override
                public void onStartTrackingTouch(SeekBar sb) {
                    userSeeking = true;
                    handler.removeCallbacks(autoHide);
                }

                @Override
                public void onStopTrackingTouch(SeekBar sb) {
                    userSeeking = false;
                    player.seekTo(sb.getProgress() * 1000L);
                    scheduleHide();
                }
            });
            seekRow.addView(seek, new LinearLayout.LayoutParams(0, dp(36), 1f));
            durText = text(15, true, MUTED);
            seekRow.addView(durText);
            bottom.addView(seekRow);
        }

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(0, dp(12), 0, dp(4));
        playBtn = roundButton();
        if (!touch) {
            controls.addView(playBtn, margins(dp(56), dp(56)));
            if (!live) {
                controls.addView(pill("−10s", v -> seekBy(-10000)), margins(-2, -2));
                controls.addView(pill("+10s", v -> seekBy(10000)), margins(-2, -2));
            }
        }
        controls.addView(pill("Audio", v -> showPanel("audio")), margins(-2, -2));
        controls.addView(pill("Subtitles", v -> showPanel("subs")), margins(-2, -2));
        if (items.length() > 1) {
            String label = live ? "Channels" : series ? "Episodes" : "More movies";
            controls.addView(pill(label, v -> showPanel("list")), margins(-2, -2));
        }
        if (series) controls.addView(pill("Next ›", v -> playNext()), margins(-2, -2));
        if (!live) {
            speedBtn = pill("Speed 1x", v -> cycleSpeed());
            controls.addView(speedBtn, margins(-2, -2));
        }
        aspectBtn = pill("Picture: Fit", v -> cycleAspect());
        controls.addView(aspectBtn, margins(-2, -2));
        hs.addView(controls);
        bottom.addView(hs);
        root.addView(bottom, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        if (touch) buildTouchUi();

        // side panel: channels / episodes / audio / subtitles
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(PANEL);
        panel.setPadding(dp(18), dp(20), dp(18), dp(16));
        panelTitle = text(22, true, WHITE);
        panel.addView(panelTitle);
        seasonScroll = new HorizontalScrollView(this);
        seasonScroll.setHorizontalScrollBarEnabled(false);
        seasonRow = new LinearLayout(this);
        seasonRow.setOrientation(LinearLayout.HORIZONTAL);
        seasonRow.setPadding(0, dp(10), 0, dp(10));
        seasonScroll.addView(seasonRow);
        panel.addView(seasonScroll);
        panelList = new ListView(this);
        panelList.setDivider(null);
        panelList.setSelector(rounded(CORAL, dp(10)));
        panelList.setCacheColorHint(Color.TRANSPARENT);
        panelList.setVerticalScrollBarEnabled(false);
        adapter = new PanelAdapter();
        panelList.setAdapter(adapter);
        panelList.setOnItemClickListener((parent, v, pos, id) -> onPanelPick(pos));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        plp.setMargins(0, dp(6), 0, 0);
        panel.addView(panelList, plp);
        panel.setVisibility(View.GONE);
        root.addView(panel, new FrameLayout.LayoutParams(dp(420), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));

        // next episode countdown
        nextCard = new LinearLayout(this);
        nextCard.setOrientation(LinearLayout.VERTICAL);
        nextCard.setBackground(rounded(PANEL, dp(14)));
        nextCard.setPadding(dp(20), dp(16), dp(20), dp(16));
        nextCount = text(14, false, MUTED);
        nextCard.addView(nextCount);
        nextTitle = text(20, true, WHITE);
        nextCard.addView(nextTitle);
        LinearLayout nextBtns = new LinearLayout(this);
        nextBtns.setOrientation(LinearLayout.HORIZONTAL);
        nextBtns.setPadding(0, dp(12), 0, 0);
        nextPlay = pill("▶  Play now", v -> playNext());
        nextBtns.addView(nextPlay, margins(-2, -2));
        nextBtns.addView(pill("Cancel", v -> cancelCountdown()), margins(-2, -2));
        nextCard.addView(nextBtns);
        nextCard.setVisibility(View.GONE);
        FrameLayout.LayoutParams nlp = new FrameLayout.LayoutParams(dp(360), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        nlp.setMargins(dp(28), dp(28), dp(28), dp(28));
        root.addView(nextCard, nlp);

        // messages and channel-number entry
        msgView = text(16, true, WHITE);
        msgView.setSingleLine(false);
        msgView.setMaxLines(4);
        msgView.setGravity(Gravity.CENTER);
        msgView.setBackground(rounded(PANEL, dp(12)));
        msgView.setPadding(dp(20), dp(12), dp(20), dp(12));
        msgView.setVisibility(View.GONE);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        root.addView(msgView, mlp);

        digitsView = text(60, true, AMBER);
        digitsView.setShadowLayer(14, 0, 2, Color.BLACK);
        digitsView.setVisibility(View.GONE);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        dlp.setMargins(0, dp(90), dp(40), 0);
        root.addView(digitsView, dlp);

        top.setVisibility(View.INVISIBLE);
        bottom.setVisibility(View.INVISIBLE);
        liveBadge.setVisibility(live ? View.VISIBLE : View.GONE);
        setContentView(root);
        root.requestFocus();
    }

    /** Phone only: centre play/skip buttons, double-tap skip hint, brightness bar, and gestures. */
    private void buildTouchUi() {
        center = new LinearLayout(this);
        center.setOrientation(LinearLayout.HORIZONTAL);
        center.setGravity(Gravity.CENTER_VERTICAL);
        if (!live) center.addView(circleButton("−10", v -> seekBy(-10000)), new LinearLayout.LayoutParams(dp(58), dp(58)));
        playBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(78), dp(78));
        pp.setMargins(dp(40), 0, dp(40), 0);
        center.addView(playBtn, pp);
        if (!live) center.addView(circleButton("+10", v -> seekBy(10000)), new LinearLayout.LayoutParams(dp(58), dp(58)));
        center.setVisibility(View.INVISIBLE);
        root.addView(center, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        seekHint = text(22, true, WHITE);
        seekHint.setGravity(Gravity.CENTER);
        seekHint.setBackground(rounded(0x66000000, dp(40)));
        seekHint.setPadding(dp(22), dp(14), dp(22), dp(14));
        seekHint.setVisibility(View.GONE);
        root.addView(seekHint, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL | Gravity.START));

        brightBox = new LinearLayout(this);
        brightBox.setOrientation(LinearLayout.VERTICAL);
        brightBox.setGravity(Gravity.CENTER_HORIZONTAL);
        brightBox.setBackground(rounded(PANEL, dp(24)));
        brightBox.setPadding(dp(10), dp(12), dp(10), dp(12));
        TextView sun = text(20, true, AMBER);
        sun.setText("☀");
        sun.setGravity(Gravity.CENTER);
        brightBox.addView(sun);
        FrameLayout track = new FrameLayout(this);
        track.setBackground(rounded(0x38FFFFFF, dp(3)));
        brightFill = new View(this);
        brightFill.setBackground(rounded(AMBER, dp(3)));
        track.addView(brightFill, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60), Gravity.BOTTOM));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(6), dp(120));
        tp.setMargins(0, dp(8), 0, dp(8));
        brightBox.addView(track, tp);
        brightPct = text(13, true, WHITE);
        brightPct.setGravity(Gravity.CENTER);
        brightBox.addView(brightPct);
        brightBox.setVisibility(View.GONE);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL | Gravity.START);
        bp.setMargins(dp(24), 0, 0, 0);
        root.addView(brightBox, bp);

        final GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                swipeBright = false;
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                // Extra quick taps on the same side keep adding 10 seconds
                if (!live && SystemClock.uptimeMillis() - lastSeekTap < 700 && sideOf(e) == seekSide) {
                    seekTap(e);
                    return true;
                }
                return false;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                if (SystemClock.uptimeMillis() - lastSeekTap < 800) return true;
                if (panelShown) hidePanel();
                else if (overlayShown) hideOverlay();
                else showOverlay(false);
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (live) {
                    if (overlayShown) hideOverlay();
                    else showOverlay(false);
                    return true;
                }
                seekTap(e);
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (e1 == null || e2 == null) return false;
                float ty = e2.getY() - e1.getY(), tx = e2.getX() - e1.getX();
                if (!swipeBright && Math.abs(ty) > dp(24) && Math.abs(ty) > Math.abs(tx) * 1.5f) {
                    swipeBright = true;
                    startBright = currentBrightness();
                }
                if (swipeBright) setBrightness(startBright - ty / (Math.max(1, root.getHeight()) * 0.8f));
                return swipeBright;
            }
        });
        view.setOnTouchListener((v, ev) -> {
            gd.onTouchEvent(ev);
            if (ev.getActionMasked() == MotionEvent.ACTION_UP || ev.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                if (swipeBright) {
                    handler.removeCallbacks(hideBright);
                    handler.postDelayed(hideBright, 1000);
                }
            }
            return true;
        });
    }

    private int sideOf(MotionEvent e) {
        return e.getX() < root.getWidth() / 2f ? -1 : 1;
    }

    private void seekTap(MotionEvent e) {
        int side = sideOf(e);
        long now = SystemClock.uptimeMillis();
        if (side != seekSide || now - lastSeekTap > 700) seekAccum = 0;
        seekSide = side;
        seekAccum += 10;
        lastSeekTap = now;
        long d = player.getDuration();
        long t = Math.max(0, player.getCurrentPosition() + side * 10000L);
        if (d > 0) t = Math.min(t, d - 1000);
        player.seekTo(t);
        seekHint.setText(side < 0 ? "«  −" + seekAccum + "s" : "+" + seekAccum + "s  »");
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) seekHint.getLayoutParams();
        lp.gravity = Gravity.CENTER_VERTICAL | (side < 0 ? Gravity.START : Gravity.END);
        lp.setMargins(dp(60), 0, dp(60), 0);
        seekHint.setLayoutParams(lp);
        seekHint.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideSeekHint);
        handler.postDelayed(hideSeekHint, 800);
        if (overlayShown) updateProgress();
    }

    private float currentBrightness() {
        float b = getWindow().getAttributes().screenBrightness;
        if (b >= 0) return b;
        try {
            return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255f;
        } catch (Exception e) {
            return 0.5f;
        }
    }

    private void setBrightness(float v) {
        v = Math.max(0.02f, Math.min(1f, v));
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = v;
        getWindow().setAttributes(lp);
        int pct = Math.round(v * 100);
        brightPct.setText(pct + "%");
        ViewGroup.LayoutParams fp = brightFill.getLayoutParams();
        fp.height = Math.max(dp(2), Math.round(dp(120) * v));
        brightFill.setLayoutParams(fp);
        brightBox.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideBright);
    }

    private TextView circleButton(String label, View.OnClickListener l) {
        TextView b = text(17, true, WHITE);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setClickable(true);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x73000000);
        g.setStroke(dp(2), 0x59FFFFFF);
        b.setBackground(g);
        b.setOnClickListener(v -> {
            scheduleHide();
            l.onClick(v);
        });
        return b;
    }

    private void buildPlayer(String ua) {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        if (ua != null && !ua.isEmpty()) http.setUserAgent(ua);
        DefaultDataSource.Factory data = new DefaultDataSource.Factory(this, http);
        // The device's own decoders play everything they can. The built-in audio decoder is added
        // last, only as a backup for sound formats (AC3, E-AC3, MP2, DTS) the device can't play.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(this) {
            @Override
            protected void buildAudioRenderers(Context context, int extensionRendererMode,
                    MediaCodecSelector mediaCodecSelector, boolean enableDecoderFallback, AudioSink audioSink,
                    Handler eventHandler, AudioRendererEventListener eventListener, ArrayList<Renderer> out) {
                super.buildAudioRenderers(context, extensionRendererMode, mediaCodecSelector,
                        enableDecoderFallback, audioSink, eventHandler, eventListener, out);
                try {
                    if (FfmpegLibrary.isAvailable()) out.add(new FfmpegAudioRenderer(eventHandler, eventListener, audioSink));
                } catch (Throwable ignored) {
                    // Backup decoder not usable on this device; the device's own decoders still work.
                }
            }
        };
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);
        renderers.setEnableDecoderFallback(true);
        // Start quickly, keep a healthy buffer for smooth playback
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 50000, 1000, 2500)
                .build();
        player = new ExoPlayer.Builder(this, renderers)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(data))
                .setLoadControl(loadControl)
                .build();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        view.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                spinner.setVisibility(state == Player.STATE_BUFFERING ? View.VISIBLE : View.GONE);
                if (state == Player.STATE_READY) retried = false;
                if (state == Player.STATE_ENDED && !live) {
                    if (series && index + 1 < items.length()) startCountdown();
                    else showOverlay(true);
                }
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                updatePlayBtn();
                if (isPlaying) scheduleHide();
                else handler.removeCallbacks(autoHide);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (!retried) {
                    retried = true;
                    String url = current().optString("url", "");
                    load(index, live ? 0 : player.getCurrentPosition(), !url.toLowerCase(Locale.ROOT).contains(".m3u8"));
                    return;
                }
                spinner.setVisibility(View.GONE);
                showMsg(current().optString("name", "") + "\nThis stream didn't play (" + error.getErrorCodeName()
                        + "). It may be offline. Try another one.", 8000);
                showOverlay(true);
            }
        });
    }

    // ---------------------------------------------------------------- playback

    private JSONObject current() {
        JSONObject o = items.optJSONObject(index);
        return o != null ? o : new JSONObject();
    }

    private void load(int i, long position, boolean forceHls) {
        try {
            loadUnsafe(i, position, forceHls);
        } catch (Throwable t) {
            showMsg("Couldn't start this stream (" + t.getClass().getSimpleName() + "). Try another one.", 8000);
        }
    }

    private void loadUnsafe(int i, long position, boolean forceHls) {
        JSONObject it = items.optJSONObject(i);
        if (it == null) return;
        index = i;
        MediaItem.Builder b = new MediaItem.Builder().setUri(Uri.parse(it.optString("url", "")));
        if (forceHls) b.setMimeType(MimeTypes.APPLICATION_M3U8);
        if (position > 0) player.setMediaItem(b.build(), position);
        else player.setMediaItem(b.build());
        player.prepare();
        player.setPlayWhenReady(true);
        spinner.setVisibility(View.VISIBLE);
        if (nextCard.getVisibility() == View.VISIBLE) {
            handler.removeCallbacks(countdownTick);
            nextCard.setVisibility(View.GONE);
        }
        updateTexts();
        if (panelShown && "list".equals(panelMode)) rebuildPanel();
        showOverlay(false);
    }

    private void togglePlay() {
        if (player.getPlaybackState() == Player.STATE_ENDED) player.seekTo(0);
        player.setPlayWhenReady(!player.getPlayWhenReady());
        updatePlayBtn();
    }

    private void seekBy(long ms) {
        if (live) return;
        long d = player.getDuration();
        long t = Math.max(0, player.getCurrentPosition() + ms);
        if (d > 0) t = Math.min(t, d - 1000);
        player.seekTo(t);
        showOverlay(false);
        updateProgress();
    }

    private void switchChannel(int delta) {
        if (!live) return;
        int n = items.length();
        retried = false;
        load(((index + delta) % n + n) % n, 0, false);
    }

    private void playNext() {
        handler.removeCallbacks(countdownTick);
        nextCard.setVisibility(View.GONE);
        if (index + 1 < items.length()) {
            retried = false;
            load(index + 1, 0, false);
        }
    }

    private void startCountdown() {
        JSONObject n = items.optJSONObject(index + 1);
        if (n == null) return;
        countdown = 8;
        nextTitle.setText(epLabel(n));
        top.setVisibility(View.INVISIBLE);
        bottom.setVisibility(View.INVISIBLE);
        if (center != null) center.setVisibility(View.INVISIBLE);
        overlayShown = false;
        nextCard.setVisibility(View.VISIBLE);
        nextPlay.requestFocus();
        handler.removeCallbacks(countdownTick);
        handler.post(countdownTick);
    }

    private void cancelCountdown() {
        handler.removeCallbacks(countdownTick);
        nextCard.setVisibility(View.GONE);
        showOverlay(true);
    }

    private void cycleSpeed() {
        speedIdx = (speedIdx + 1) % SPEEDS.length;
        player.setPlaybackSpeed(SPEEDS[speedIdx]);
        String s = speedLabel(SPEEDS[speedIdx]);
        if (speedBtn != null) speedBtn.setText("Speed " + s);
        showMsg("Speed " + s, 1200);
    }

    private void cycleAspect() {
        resizeMode = (resizeMode + 1) % 3;
        int[] modes = {AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
        String[] names = {"Fit", "Stretch", "Zoom"};
        view.setResizeMode(modes[resizeMode]);
        aspectBtn.setText("Picture: " + names[resizeMode]);
        showMsg("Picture: " + names[resizeMode], 1200);
    }

    private void jumpToDigits() {
        digitsView.setVisibility(View.GONE);
        if (digits.length() == 0) return;
        int want;
        try {
            want = Integer.parseInt(digits.toString());
        } catch (NumberFormatException e) {
            want = -1;
        }
        digits.setLength(0);
        for (int i = 0; i < items.length(); i++) {
            JSONObject o = items.optJSONObject(i);
            if (o != null && o.optInt("num", -2) == want) {
                retried = false;
                load(i, 0, false);
                return;
            }
        }
        showMsg("No channel " + want + " in this list", 2500);
    }

    // ---------------------------------------------------------------- overlay

    private void showOverlay(boolean focusControls) {
        top.setVisibility(View.VISIBLE);
        bottom.setVisibility(View.VISIBLE);
        if (center != null) center.setVisibility(View.VISIBLE);
        overlayShown = true;
        updateTexts();
        updateProgress();
        if (focusControls && !panelShown && !touch) playBtn.requestFocus();
        scheduleHide();
    }

    private void hideOverlay() {
        if (panelShown || nextCard.getVisibility() == View.VISIBLE) return;
        top.setVisibility(View.INVISIBLE);
        bottom.setVisibility(View.INVISIBLE);
        if (center != null) center.setVisibility(View.INVISIBLE);
        overlayShown = false;
        root.requestFocus();
    }

    private void scheduleHide() {
        handler.removeCallbacks(autoHide);
        if (!panelShown && player != null && player.isPlaying()) handler.postDelayed(autoHide, 5000);
    }

    private void updatePlayBtn() {
        if (playBtn != null && player != null) playBtn.setText(player.getPlayWhenReady() ? "II" : "▶");
    }

    private void updateTexts() {
        JSONObject it = current();
        String name = it.optString("name", "");
        String group = it.optString("group", "");
        if (live) {
            int num = it.optInt("num", 0);
            kicker.setText((num > 0 ? num + "   " : "") + group.toUpperCase(Locale.getDefault()));
            title.setText(name);
            subtitle.setVisibility(View.GONE);
        } else if (series) {
            String show = it.optString("series", "");
            kicker.setText("SERIES");
            title.setText(show.isEmpty() ? name : show);
            String s = seasonShort(group);
            int ep = it.optInt("ep", 0);
            String line = s + (ep > 0 ? (s.isEmpty() ? "" : " · ") + "E" + ep : "");
            if (!show.isEmpty()) line = line + (line.isEmpty() ? "" : "   ") + name;
            subtitle.setText(line);
            subtitle.setVisibility(line.isEmpty() ? View.GONE : View.VISIBLE);
        } else {
            kicker.setText("MOVIE");
            title.setText(name);
            subtitle.setText(group);
            subtitle.setVisibility(group.isEmpty() ? View.GONE : View.VISIBLE);
        }
        updatePlayBtn();
    }

    private void updateProgress() {
        if (clockView != null) clockView.setText(clock.format(new Date()));
        if (!overlayShown || player == null) return;
        if (live) {
            JSONArray epg = current().optJSONArray("epg");
            long now = System.currentTimeMillis();
            String nowLine = "", nextLine = "";
            int prog = 0;
            if (epg != null) {
                for (int i = 0; i < epg.length(); i++) {
                    JSONArray p = epg.optJSONArray(i);
                    if (p == null) continue;
                    long s = p.optLong(0), e = p.optLong(1);
                    if (e <= now) continue;
                    if (s <= now && nowLine.isEmpty()) {
                        nowLine = p.optString(2, "") + "   " + clock.format(new Date(s)) + " – " + clock.format(new Date(e));
                        prog = (int) ((now - s) * 1000 / Math.max(1, e - s));
                    } else if (nextLine.isEmpty()) {
                        nextLine = "Next   " + clock.format(new Date(s)) + "   " + p.optString(2, "");
                    }
                }
            }
            nowText.setText(nowLine.isEmpty() ? "No guide information" : nowLine);
            epgBar.setVisibility(nowLine.isEmpty() ? View.INVISIBLE : View.VISIBLE);
            epgBar.setProgress(prog);
            nextText.setText(nextLine);
            nextText.setVisibility(nextLine.isEmpty() ? View.GONE : View.VISIBLE);
        } else {
            long d = player.getDuration(), p = Math.max(0, player.getCurrentPosition());
            if (d > 0) {
                seek.setMax((int) (d / 1000));
                if (!userSeeking) seek.setProgress((int) (p / 1000));
                durText.setText("−" + fmt(Math.max(0, d - p)));
            } else durText.setText("");
            if (!userSeeking) posText.setText(fmt(p));
        }
        updatePlayBtn();
    }

    private void showMsg(String text, long ms) {
        msgView.setText(text);
        msgView.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideMsg);
        handler.postDelayed(hideMsg, ms);
    }

    // ---------------------------------------------------------------- side panel

    private void showPanel(String mode) {
        panelMode = mode;
        panelShown = true;
        handler.removeCallbacks(autoHide);
        if (live && "list".equals(mode)) {
            top.setVisibility(View.VISIBLE);
            bottom.setVisibility(View.VISIBLE);
            overlayShown = true;
            updateTexts();
            updateProgress();
        }
        panel.setVisibility(View.VISIBLE);
        if (center != null) center.setVisibility(View.INVISIBLE);
        rebuildPanel();
        panelList.requestFocus();
    }

    private void hidePanel() {
        panel.setVisibility(View.GONE);
        panelShown = false;
        if (overlayShown && center != null) center.setVisibility(View.VISIBLE);
        if (overlayShown) {
            playBtn.requestFocus();
            scheduleHide();
        } else root.requestFocus();
    }

    private void rebuildPanel() {
        rows.clear();
        refs.clear();
        seasonRow.removeAllViews();
        seasonScroll.setVisibility(View.GONE);
        panelCurrent = -1;
        if ("list".equals(panelMode)) {
            if (series) {
                panelTitle.setText("Episodes");
                List<String> seasons = new ArrayList<>();
                for (int i = 0; i < items.length(); i++) {
                    String g = items.optJSONObject(i).optString("group", "");
                    if (!seasons.contains(g)) seasons.add(g);
                }
                if (season == null || !seasons.contains(season)) season = current().optString("group", "");
                if (seasons.size() > 1) {
                    seasonScroll.setVisibility(View.VISIBLE);
                    for (final String s : seasons) {
                        TextView chip = pill(s.isEmpty() ? "Other" : s, v -> {
                            season = s;
                            rebuildPanel();
                            panelList.requestFocus();
                        });
                        if (s.equals(season)) {
                            chip.setBackground(states(AMBER, WHITE, dp(10)));
                            chip.setTextColor(NAVY);
                        }
                        seasonRow.addView(chip, margins(-2, -2));
                    }
                }
                for (int i = 0; i < items.length(); i++) {
                    JSONObject o = items.optJSONObject(i);
                    if (seasons.size() > 1 && !o.optString("group", "").equals(season)) continue;
                    if (i == index) panelCurrent = rows.size();
                    rows.add(new String[]{epLabel(o), i == index ? "▶ Playing now" : ""});
                    refs.add(i);
                }
            } else {
                panelTitle.setText(live ? "Channels" : "More movies");
                for (int i = 0; i < items.length(); i++) {
                    JSONObject o = items.optJSONObject(i);
                    int num = o.optInt("num", 0);
                    String a = (live && num > 0 ? num + "   " : "") + o.optString("name", "");
                    String b = i == index ? "▶ Playing now" : live ? nowTitle(o) : o.optString("group", "");
                    if (i == index) panelCurrent = rows.size();
                    rows.add(new String[]{a, b});
                    refs.add(i);
                }
            }
        } else {
            int type = "audio".equals(panelMode) ? C.TRACK_TYPE_AUDIO : C.TRACK_TYPE_TEXT;
            panelTitle.setText(type == C.TRACK_TYPE_AUDIO ? "Audio" : "Subtitles");
            TrackSelectionParameters params = player.getTrackSelectionParameters();
            boolean disabled = params.disabledTrackTypes.contains(type);
            if (type == C.TRACK_TYPE_TEXT) {
                rows.add(new String[]{"Off", ""});
                refs.add("off");
            } else {
                rows.add(new String[]{"Automatic", "Best match for this device"});
                refs.add("auto");
            }
            int n = 0;
            for (Tracks.Group g : player.getCurrentTracks().getGroups()) {
                if (g.getType() != type) continue;
                for (int t = 0; t < g.length; t++) {
                    if (!g.isTrackSupported(t)) continue;
                    n++;
                    Format f = g.getTrackFormat(t);
                    if (!disabled && g.isTrackSelected(t)) panelCurrent = rows.size();
                    rows.add(new String[]{trackName(f, n), trackDetail(f, type)});
                    refs.add(new Object[]{g, t});
                }
            }
            if (n == 0) {
                rows.add(new String[]{type == C.TRACK_TYPE_AUDIO ? "Only one audio track" : "No subtitles in this stream", ""});
                refs.add(null);
            }
            if (panelCurrent < 0) panelCurrent = 0;
        }
        adapter.notifyDataSetChanged();
        panelList.setSelection(Math.max(0, panelCurrent));
    }

    private void onPanelPick(int pos) {
        if (pos < 0 || pos >= refs.size()) return;
        Object ref = refs.get(pos);
        if ("list".equals(panelMode)) {
            if (ref instanceof Integer) {
                int i = (Integer) ref;
                hidePanel();
                if (i != index) {
                    retried = false;
                    load(i, 0, false);
                }
            }
            return;
        }
        int type = "audio".equals(panelMode) ? C.TRACK_TYPE_AUDIO : C.TRACK_TYPE_TEXT;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if ("off".equals(ref)) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true);
        } else if ("auto".equals(ref)) {
            b.setTrackTypeDisabled(type, false).clearOverridesOfType(type);
        } else if (ref instanceof Object[]) {
            Tracks.Group g = (Tracks.Group) ((Object[]) ref)[0];
            int t = (Integer) ((Object[]) ref)[1];
            b.setTrackTypeDisabled(type, false).setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), t));
        } else {
            hidePanel();
            return;
        }
        player.setTrackSelectionParameters(b.build());
        showMsg(rows.get(pos)[0], 1500);
        hidePanel();
    }

    private class PanelAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int p) {
            return rows.get(p);
        }

        @Override
        public long getItemId(int p) {
            return p;
        }

        @Override
        public View getView(int p, View cv, ViewGroup parent) {
            LinearLayout row;
            TextView a, b;
            if (cv instanceof LinearLayout) {
                row = (LinearLayout) cv;
                a = (TextView) row.getChildAt(0);
                b = (TextView) row.getChildAt(1);
            } else {
                row = new LinearLayout(PlayerActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(14), dp(10), dp(14), dp(10));
                a = text(17, true, WHITE);
                b = text(13, false, MUTED);
                row.addView(a);
                row.addView(b);
            }
            String[] r = rows.get(p);
            a.setText(r[0]);
            a.setTextColor(p == panelCurrent ? AMBER : WHITE);
            b.setText(r[1]);
            b.setVisibility(r[1].isEmpty() ? View.GONE : View.VISIBLE);
            return row;
        }
    }

    // ---------------------------------------------------------------- remote control

    private boolean isOk(int code) {
        return code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER || code == KeyEvent.KEYCODE_BUTTON_A;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        boolean first = down && e.getRepeatCount() == 0;
        boolean nextVisible = nextCard != null && nextCard.getVisibility() == View.VISIBLE;

        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_ESCAPE) {
            if (!down) {
                if (nextVisible) cancelCountdown();
                else if (panelShown) hidePanel();
                else if (overlayShown) hideOverlay();
                else finishWithResult();
            }
            return true;
        }
        if (player == null) return super.dispatchKeyEvent(e);
        if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || code == KeyEvent.KEYCODE_MEDIA_PLAY || code == KeyEvent.KEYCODE_MEDIA_PAUSE) {
            if (first) {
                if (code == KeyEvent.KEYCODE_MEDIA_PLAY) player.play();
                else if (code == KeyEvent.KEYCODE_MEDIA_PAUSE) player.pause();
                else togglePlay();
                showOverlay(false);
            }
            return true;
        }
        if (!live && (code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || code == KeyEvent.KEYCODE_MEDIA_REWIND)) {
            if (down) seekBy(code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ? 10000 : -10000);
            return true;
        }
        if (series && code == KeyEvent.KEYCODE_MEDIA_NEXT) {
            if (first) playNext();
            return true;
        }
        if (live && (code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_CHANNEL_DOWN
                || code == KeyEvent.KEYCODE_PAGE_UP || code == KeyEvent.KEYCODE_PAGE_DOWN)) {
            if (first) switchChannel(code == KeyEvent.KEYCODE_CHANNEL_UP || code == KeyEvent.KEYCODE_PAGE_UP ? 1 : -1);
            return true;
        }
        if (live && !panelShown && code >= KeyEvent.KEYCODE_0 && code <= KeyEvent.KEYCODE_9) {
            if (down) {
                if (digits.length() < 4) digits.append((char) ('0' + (code - KeyEvent.KEYCODE_0)));
                digitsView.setText(digits.toString());
                digitsView.setVisibility(View.VISIBLE);
                handler.removeCallbacks(jump);
                handler.postDelayed(jump, 1500);
            }
            return true;
        }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_PROG_YELLOW) {
            if (first) cycleAspect();
            return true;
        }
        if (code == KeyEvent.KEYCODE_INFO || code == KeyEvent.KEYCODE_GUIDE) {
            if (first) {
                if (live || series) showPanel("list");
                else showOverlay(true);
            }
            return true;
        }

        View focus = getCurrentFocus();
        boolean controlsFocused = focus != null && focus != root;
        if (nextVisible || panelShown || (overlayShown && controlsFocused)) {
            if (down && !panelShown) scheduleHide();
            return super.dispatchKeyEvent(e);
        }

        boolean dpad = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN
                || code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT || isOk(code);
        if (!dpad) return super.dispatchKeyEvent(e);
        if (down) {
            if (live) {
                if (first) {
                    if (code == KeyEvent.KEYCODE_DPAD_UP) switchChannel(1);
                    else if (code == KeyEvent.KEYCODE_DPAD_DOWN) switchChannel(-1);
                    else if (code == KeyEvent.KEYCODE_DPAD_LEFT) showPanel("list");
                    else showOverlay(true);
                }
            } else {
                if (code == KeyEvent.KEYCODE_DPAD_LEFT) seekBy(-10000);
                else if (code == KeyEvent.KEYCODE_DPAD_RIGHT) seekBy(10000);
                else if (first) {
                    if (isOk(code)) togglePlay();
                    showOverlay(true);
                }
            }
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        finishWithResult();
    }

    private void finishWithResult() {
        Intent r = new Intent();
        r.putExtra("index", index);
        if (player != null && !live) {
            r.putExtra("position", Math.max(0, player.getCurrentPosition()));
            r.putExtra("duration", Math.max(0, player.getDuration()));
        } else {
            r.putExtra("position", -1L);
            r.putExtra("duration", 0L);
        }
        setResult(RESULT_OK, r);
        finish();
    }

    // ---------------------------------------------------------------- helpers

    private String epLabel(JSONObject o) {
        int ep = o.optInt("ep", 0);
        String name = o.optString("name", "");
        return ep > 0 ? "E" + ep + "   " + name : name;
    }

    private String seasonShort(String g) {
        if (g == null) return "";
        if (g.startsWith("Season ")) return "S" + g.substring(7).trim();
        return g;
    }

    private String nowTitle(JSONObject o) {
        JSONArray epg = o.optJSONArray("epg");
        if (epg == null) return o.optString("group", "");
        long now = System.currentTimeMillis();
        for (int i = 0; i < epg.length(); i++) {
            JSONArray p = epg.optJSONArray(i);
            if (p != null && p.optLong(0) <= now && p.optLong(1) > now) return p.optString(2, "");
        }
        return o.optString("group", "");
    }

    private String trackName(Format f, int n) {
        if (f.label != null && !f.label.isEmpty()) return f.label;
        if (f.language != null && !f.language.isEmpty() && !"und".equals(f.language)) {
            String name = new Locale(f.language).getDisplayLanguage();
            return name == null || name.isEmpty() ? f.language : name;
        }
        return "Track " + n;
    }

    private String trackDetail(Format f, int type) {
        String mime = f.sampleMimeType == null ? "" : f.sampleMimeType;
        if (type == C.TRACK_TYPE_AUDIO) {
            String ch = f.channelCount == 1 ? "Mono" : f.channelCount == 2 ? "Stereo" : f.channelCount == 6 ? "5.1"
                    : f.channelCount == 8 ? "7.1" : f.channelCount > 0 ? f.channelCount + " channels" : "";
            String codec = mime.contains("eac3") ? "Dolby Digital Plus" : mime.contains("ac3") ? "Dolby Digital"
                    : mime.contains("mp4a") ? "AAC" : mime.contains("mpeg-L2") ? "MP2" : mime.equals("audio/mpeg") ? "MP3"
                    : mime.contains("dts") ? "DTS" : mime.contains("opus") ? "Opus" : "";
            return (ch + (ch.isEmpty() || codec.isEmpty() ? "" : "  ") + codec).trim();
        }
        return mime.replace("application/", "").replace("text/", "");
    }

    private String speedLabel(float s) {
        return s == (int) s ? ((int) s) + "x" : s + "x";
    }

    private String fmt(long ms) {
        long s = ms / 1000, h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, sec) : String.format(Locale.US, "%d:%02d", m, sec);
    }

    private TextView text(float sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    private TextView pill(String label, View.OnClickListener l) {
        TextView b = text(15, true, WHITE);
        b.setText(label);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(9), dp(16), dp(9));
        b.setFocusable(true);
        b.setClickable(true);
        b.setBackground(states(0x2EFFFFFF, WHITE, dp(10)));
        b.setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_focused}, {android.R.attr.state_pressed}, {}},
                new int[]{NAVY, NAVY, WHITE}));
        b.setOnClickListener(v -> {
            scheduleHide();
            l.onClick(v);
        });
        return b;
    }

    private TextView roundButton() {
        TextView b = text(20, true, WHITE);
        b.setGravity(Gravity.CENTER);
        b.setText("II");
        b.setFocusable(true);
        b.setClickable(true);
        GradientDrawable on = new GradientDrawable();
        on.setShape(GradientDrawable.OVAL);
        on.setColor(WHITE);
        GradientDrawable off = new GradientDrawable();
        off.setShape(GradientDrawable.OVAL);
        off.setColor(CORAL);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, on);
        s.addState(new int[]{android.R.attr.state_pressed}, on);
        s.addState(new int[]{}, off);
        b.setBackground(s);
        b.setTextColor(new ColorStateList(
                new int[][]{{android.R.attr.state_focused}, {android.R.attr.state_pressed}, {}},
                new int[]{CORAL, CORAL, WHITE}));
        b.setOnClickListener(v -> {
            togglePlay();
            scheduleHide();
        });
        return b;
    }

    private StateListDrawable states(int normal, int focused, int radius) {
        GradientDrawable on = new GradientDrawable();
        on.setColor(focused);
        on.setCornerRadius(radius);
        GradientDrawable off = new GradientDrawable();
        off.setColor(normal);
        off.setCornerRadius(radius);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, on);
        s.addState(new int[]{android.R.attr.state_pressed}, on);
        s.addState(new int[]{}, off);
        return s;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private LinearLayout.LayoutParams margins(int w, int h) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(0, 0, dp(10), 0);
        return lp;
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    // ---------------------------------------------------------------- lifecycle

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
