package com.signal.iptv;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.ArrayAdapter;

import androidx.mediarouter.app.MediaRouteButton;
import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.CastMediaControlIntent;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaSeekOptions;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

/**
 * Chromecast / Google TV casting for phones. The TV fetches the stream itself; the phone becomes the remote.
 * Everything is wrapped so a phone without Google Play services simply has no Cast button.
 */
public class CastHelper {
    public interface Listener {
        /** Cast is ready (true) or not available on this phone (false). */
        void onCastReady(boolean available);

        void onCastStarted(String deviceName);

        void onCastEnded(long lastPositionMs);

        void onCastMessage(String text);
    }

    private final Activity act;
    private final Listener listener;
    private CastContext ctx;
    private SessionManager sessions;
    private MediaRouter router;
    private MediaRouteSelector selector;
    private CastSession session;
    private MediaRouteButton routeButton;
    private long lastPos;
    private boolean errorShown;
    private ArrayAdapter<String> pickerAdapter;
    private final List<MediaRouter.RouteInfo> pickerRoutes = new ArrayList<>();

    private final MediaRouter.Callback routerCb = new MediaRouter.Callback() {
        @Override
        public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo route) {
            refreshPicker();
        }

        @Override
        public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo route) {
            refreshPicker();
        }

        @Override
        public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo route) {
            refreshPicker();
        }
    };

    private final RemoteMediaClient.Callback mediaCb = new RemoteMediaClient.Callback() {
        @Override
        public void onStatusUpdated() {
            RemoteMediaClient c = client();
            if (c == null) return;
            lastPos = c.getApproximateStreamPosition();
            MediaStatus st = c.getMediaStatus();
            if (st != null && st.getPlayerState() == MediaStatus.PLAYER_STATE_IDLE
                    && st.getIdleReason() == MediaStatus.IDLE_REASON_ERROR && !errorShown) {
                errorShown = true;
                listener.onCastMessage("Your TV couldn't play this channel through Cast (its format isn't supported). Try Mirror screen instead.");
            }
        }
    };

    private final SessionManagerListener<CastSession> sessionCb = new SessionManagerListener<CastSession>() {
        @Override
        public void onSessionStarting(CastSession s) {
        }

        @Override
        public void onSessionStarted(CastSession s, String id) {
            attach(s);
        }

        @Override
        public void onSessionStartFailed(CastSession s, int error) {
            listener.onCastMessage("Couldn't connect to the TV. Make sure it's on and on the same Wi-Fi.");
        }

        @Override
        public void onSessionEnding(CastSession s) {
            RemoteMediaClient c = client();
            if (c != null) lastPos = c.getApproximateStreamPosition();
        }

        @Override
        public void onSessionEnded(CastSession s, int error) {
            detach();
        }

        @Override
        public void onSessionResuming(CastSession s, String id) {
        }

        @Override
        public void onSessionResumed(CastSession s, boolean wasSuspended) {
            attach(s);
        }

        @Override
        public void onSessionResumeFailed(CastSession s, int error) {
        }

        @Override
        public void onSessionSuspended(CastSession s, int reason) {
        }
    };

    public CastHelper(Activity act, Listener listener) {
        this.act = act;
        this.listener = listener;
        try {
            // Current recommended way to start Cast (the older instant version is being retired)
            CastContext.getSharedInstance(act.getApplicationContext(), Executors.newSingleThreadExecutor())
                    .addOnSuccessListener(act, c -> {
                        try {
                            init(c);
                            listener.onCastReady(true);
                        } catch (Throwable t) {
                            ctx = null;
                            listener.onCastReady(false);
                        }
                    })
                    .addOnFailureListener(act, e -> {
                        ctx = null;   // no Google Play services, or Cast not available on this phone
                        listener.onCastReady(false);
                    });
        } catch (Throwable t) {
            ctx = null;
            act.runOnUiThread(() -> listener.onCastReady(false));
        }
    }

    private void init(CastContext c) {
        ctx = c;
        sessions = ctx.getSessionManager();
        sessions.addSessionManagerListener(sessionCb, CastSession.class);
        router = MediaRouter.getInstance(act);
        selector = ctx.getMergedSelector();
        if (selector == null) selector = new MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                .build();
        if (routeButton != null) routeButton.setRouteSelector(selector);
    }

    public boolean available() {
        return ctx != null && router != null;
    }

    public boolean isCasting() {
        return session != null && session.isConnected();
    }

    public String deviceName() {
        try {
            return session.getCastDevice().getFriendlyName();
        } catch (Throwable t) {
            return "TV";
        }
    }

    public long position() {
        RemoteMediaClient c = client();
        return c != null ? c.getApproximateStreamPosition() : lastPos;
    }

    private RemoteMediaClient client() {
        try {
            return session != null ? session.getRemoteMediaClient() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** An already running Cast session (for example, after reopening the player). */
    public void resumeExisting() {
        if (!available()) return;
        try {
            CastSession s = sessions.getCurrentCastSession();
            if (s != null && s.isConnected()) attach(s);
        } catch (Throwable ignored) {
        }
    }

    private void attach(CastSession s) {
        session = s;
        errorShown = false;
        RemoteMediaClient c = client();
        if (c != null) c.registerCallback(mediaCb);
        listener.onCastStarted(deviceName());
    }

    private void detach() {
        RemoteMediaClient c = client();
        if (c != null) {
            try {
                c.unregisterCallback(mediaCb);
            } catch (Throwable ignored) {
            }
        }
        boolean was = session != null;
        session = null;
        if (was) listener.onCastEnded(lastPos);
    }

    // ------------------------------------------------------------ device picker

    private List<MediaRouter.RouteInfo> routes() {
        List<MediaRouter.RouteInfo> out = new ArrayList<>();
        if (router == null) return out;
        for (MediaRouter.RouteInfo r : router.getRoutes()) {
            if (!r.isDefault() && !r.isBluetooth() && r.isEnabled() && r.matchesSelector(selector)) out.add(r);
        }
        return out;
    }

    private void refreshPicker() {
        if (pickerAdapter == null) return;
        pickerRoutes.clear();
        pickerRoutes.addAll(routes());
        pickerAdapter.clear();
        for (MediaRouter.RouteInfo r : pickerRoutes) pickerAdapter.add(r.getName());
        if (pickerRoutes.isEmpty()) pickerAdapter.add("Looking for Chromecast and Google TV…");
        pickerAdapter.notifyDataSetChanged();
    }

    /** Google's own Cast button: its chooser starts the device search the same way other apps do. */
    public void setRouteButton(MediaRouteButton b) {
        try {
            routeButton = b;
            if (selector != null) b.setRouteSelector(selector);
        } catch (Throwable t) {
            routeButton = null;
        }
    }

    /** Shows the TVs on this Wi-Fi, or (while casting) a choice to stop. */
    public void showPicker() {
        if (!available()) {
            listener.onCastMessage("Cast is still starting, or this phone doesn't have Google Play services. Try again in a moment, or use Mirror screen.");
            return;
        }
        if (isCasting()) {
            new AlertDialog.Builder(act)
                    .setTitle("Casting to " + deviceName())
                    .setPositiveButton("Stop casting", (d, w) -> stop())
                    .setNegativeButton("Close", null)
                    .show();
            return;
        }
        if (routeButton != null) {
            try {
                if (routeButton.showDialog()) return;
            } catch (Throwable ignored) {
            }
        }
        // Backup: our own simple list
        router.addCallback(selector, routerCb, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN | MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY);
        pickerAdapter = new ArrayAdapter<>(act, android.R.layout.simple_list_item_1, new ArrayList<>());
        refreshPicker();
        new AlertDialog.Builder(act)
                .setTitle("Cast to")
                .setAdapter(pickerAdapter, (d, which) -> {
                    if (which >= 0 && which < pickerRoutes.size()) {
                        listener.onCastMessage("Connecting to " + pickerRoutes.get(which).getName() + "…");
                        router.selectRoute(pickerRoutes.get(which));
                    }
                })
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(d -> {
                    pickerAdapter = null;
                    try {
                        router.removeCallback(routerCb);
                    } catch (Throwable ignored) {
                    }
                })
                .show();
    }

    public void stop() {
        try {
            if (sessions != null) sessions.endCurrentSession(true);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------ playback on the TV

    public void load(String url, String title, boolean live, long positionMs) {
        RemoteMediaClient c = client();
        if (c == null || url == null || url.isEmpty()) return;
        String u = url;
        String low = u.toLowerCase(Locale.ROOT);
        // Chromecast plays HLS, not raw .ts: Xtream live channels offer both, so ask for HLS
        if (live && low.matches(".*\\.ts(\\?.*)?$")) {
            u = u.replaceFirst("(?i)\\.ts(\\?|$)", ".m3u8$1");
            low = u.toLowerCase(Locale.ROOT);
        }
        String type = low.contains(".m3u8") ? "application/x-mpegURL"
                : low.contains(".mp4") || low.contains(".m4v") ? "video/mp4"
                : low.contains(".mkv") ? "video/x-matroska"
                : low.contains(".webm") ? "video/webm"
                : live ? "application/x-mpegURL" : "video/mp4";
        MediaMetadata md = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        md.putString(MediaMetadata.KEY_TITLE, title == null ? "" : title);
        MediaInfo info = new MediaInfo.Builder(u)
                .setStreamType(live ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(type)
                .setMetadata(md)
                .build();
        MediaLoadRequestData req = new MediaLoadRequestData.Builder()
                .setMediaInfo(info)
                .setAutoplay(true)
                .setCurrentTime(live ? 0 : Math.max(0, positionMs))
                .build();
        errorShown = false;
        try {
            c.load(req).setResultCallback(r -> {
                if (!r.getStatus().isSuccess() && !errorShown) {
                    errorShown = true;
                    listener.onCastMessage("Your TV couldn't play this through Cast (its format isn't supported). Try Mirror screen instead.");
                }
            });
        } catch (Throwable t) {
            listener.onCastMessage("Couldn't send this to the TV.");
        }
    }

    public void togglePlayback() {
        RemoteMediaClient c = client();
        if (c != null) c.togglePlayback();
    }

    public void seekBy(long ms) {
        RemoteMediaClient c = client();
        if (c == null) return;
        long t = Math.max(0, c.getApproximateStreamPosition() + ms);
        c.seek(new MediaSeekOptions.Builder().setPosition(t).build());
    }

    /** Player closing: stop listening (and leave the TV quietly, without resuming the phone player). */
    public void release() {
        try {
            if (sessions != null) sessions.removeSessionManagerListener(sessionCb, CastSession.class);
            if (router != null) router.removeCallback(routerCb);
            RemoteMediaClient c = client();
            if (c != null) c.unregisterCallback(mediaCb);
        } catch (Throwable ignored) {
        }
        session = null;
    }
}
