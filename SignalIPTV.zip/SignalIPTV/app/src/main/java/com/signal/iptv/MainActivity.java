package com.signal.iptv;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 42;
    private static final int REQ_PLAY = 43;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private boolean tv;
    private volatile boolean typing;
    private File pendingApk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        installCrashReporter();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        tv = (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback")
                || !getPackageManager().hasSystemFeature("android.hardware.touchscreen");

        web = new WebView(this);
        web.setBackgroundColor(0xFF0F1A33);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        // Lets the bundled app read playlists, logins and TV guides from any server
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose playlist"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/index.html");
    }

    /** Methods the app page can call. */
    public class Bridge {
        @JavascriptInterface
        public boolean isTv() {
            return tv;
        }

        /** Saves the channel lists and TV guide on the device so the app opens instantly. */
        @JavascriptInterface
        public boolean saveText(String name, String text) {
            File f = cacheFile(name);
            if (f == null || text == null) return false;
            File tmp = new File(f.getPath() + ".tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                tmp.delete();
                return false;
            }
            return tmp.renameTo(f);
        }

        @JavascriptInterface
        public String loadText(String name) {
            File f = cacheFile(name);
            if (f == null || !f.exists()) return null;
            try (InputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream((int) Math.max(1024, f.length()));
                byte[] chunk = new byte[65536];
                int n;
                while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n);
                return new String(buf.toByteArray(), StandardCharsets.UTF_8);
            } catch (Exception e) {
                return null;
            }
        }

        @JavascriptInterface
        public void deleteText(String name) {
            File f = cacheFile(name);
            if (f != null) f.delete();
        }

        /** Returns the saved crash report (and removes it), or null. */
        @JavascriptInterface
        public String takeCrashReport() {
            File f = new File(getFilesDir(), "last_crash.txt");
            if (!f.exists()) return null;
            try (InputStream in = new FileInputStream(f)) {
                byte[] b = new byte[(int) Math.min(f.length(), 20000)];
                int n = in.read(b);
                return n > 0 ? new String(b, 0, n, StandardCharsets.UTF_8) : null;
            } catch (Exception e) {
                return null;
            } finally {
                f.delete();
            }
        }

        @JavascriptInterface
        public int appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            } catch (Exception e) {
                return 0;
            }
        }

        /** Downloads a new version of the app and opens the Android installer. */
        @JavascriptInterface
        public void installUpdate(final String url) {
            new Thread(() -> {
                HttpURLConnection c = null;
                try {
                    File dir = Build.VERSION.SDK_INT >= 24 ? new File(getCacheDir(), "updates")
                            : new File(getExternalCacheDir(), "updates");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("no storage space");
                    final File apk = new File(dir, "signal-tv.apk");
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(30000);
                    int code = c.getResponseCode();
                    if (code != 200) throw new Exception("server replied " + code);
                    long total = c.getContentLength();
                    try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(apk)) {
                        byte[] buf = new byte[65536];
                        long done = 0;
                        int n, last = -5;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            done += n;
                            if (total > 0) {
                                int pct = (int) (done * 100 / total);
                                if (pct >= last + 5) {
                                    last = pct;
                                    js("window.updateProgress&&updateProgress(" + pct + ")");
                                }
                            }
                        }
                    }
                    if (Build.VERSION.SDK_INT < 24) apk.setReadable(true, false);
                    runOnUiThread(() -> openInstaller(apk));
                } catch (Throwable t) {
                    js("window.updateFailed&&updateFailed(" + JSONObject.quote(String.valueOf(t.getMessage())) + ")");
                } finally {
                    if (c != null) c.disconnect();
                }
            }).start();
        }

        @JavascriptInterface
        public String deviceInfo() {
            return "Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + "), "
                    + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + ", "
                    + android.os.Build.SUPPORTED_ABIS[0];
        }

        @JavascriptInterface
        public void setTyping(boolean t) {
            typing = t;
        }

        @JavascriptInterface
        public void play(final String json, final int index, final boolean live, final double position, final String ua) {
            runOnUiThread(() -> {
                try {
                    PlayerActivity.items = new JSONArray(json);
                } catch (Throwable e) {
                    web.evaluateJavascript("window.toast&&toast('Could not open the player: " + e.getClass().getSimpleName() + "',6000)", null);
                    return;
                }
                Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                i.putExtra("index", index);
                i.putExtra("live", live);
                i.putExtra("position", (long) (position * 1000));
                i.putExtra("ua", ua == null ? "" : ua);
                startActivityForResult(i, REQ_PLAY);
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] result = (res == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (req == REQ_PLAY && data != null) {
            int idx = data.getIntExtra("index", 0);
            long pos = data.getLongExtra("position", -1);
            long dur = data.getLongExtra("duration", 0);
            web.evaluateJavascript("window.onNativeResult&&window.onNativeResult(" + idx + "," + pos + "," + dur + ")", null);
        }
    }

    private void js(final String code) {
        runOnUiThread(() -> web.evaluateJavascript(code, null));
    }

    private void openInstaller(File apk) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                pendingApk = apk;
                js("window.toast&&toast('Allow Signal TV to install updates, then press Back',8000)");
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName())));
                    return;
                } catch (ActivityNotFoundException e) {
                    // Some TV boxes have no such screen; try the installer directly.
                }
            }
            pendingApk = null;
            Uri uri = Build.VERSION.SDK_INT >= 24
                    ? FileProvider.getUriForFile(this, "com.signal.iptv.files", apk)
                    : Uri.fromFile(apk);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable t) {
            js("window.updateFailed&&updateFailed(" + JSONObject.quote("couldn't open the installer (" + t.getMessage() + ")") + ")");
        }
    }

    /** Saves the error if the app crashes, so it can be shown the next time the app opens. */
    private void installCrashReporter() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        final File out = new File(getFilesDir(), "last_crash.txt");
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringWriter sw = new StringWriter();
                error.printStackTrace(new PrintWriter(sw));
                String text = "Android " + android.os.Build.VERSION.RELEASE + " (API " + android.os.Build.VERSION.SDK_INT + "), "
                        + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + "\n" + sw;
                try (OutputStream o = new FileOutputStream(out)) {
                    o.write(text.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Throwable ignored) {
            }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    private File cacheFile(String name) {
        if (name == null || !name.matches("[A-Za-z0-9._-]{1,120}")) return null;
        File dir = new File(getFilesDir(), "store");
        if (!dir.exists() && !dir.mkdirs()) return null;
        return new File(dir, name);
    }

    private void handleBack() {
        web.evaluateJavascript("window.appBack?String(window.appBack()):'false'", v -> {
            if (v == null || !v.contains("true")) finish();
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) handleBack();
            return true;
        }
        if (!typing) {
            String k = null;
            switch (e.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_UP: k = "up"; break;
                case KeyEvent.KEYCODE_DPAD_DOWN: k = "down"; break;
                case KeyEvent.KEYCODE_DPAD_LEFT: k = "left"; break;
                case KeyEvent.KEYCODE_DPAD_RIGHT: k = "right"; break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                case KeyEvent.KEYCODE_BUTTON_A: k = "ok"; break;
                default: break;
            }
            if (k != null) {
                if (e.getAction() == KeyEvent.ACTION_DOWN && (!"ok".equals(k) || e.getRepeatCount() == 0)) {
                    web.evaluateJavascript("window.remoteKey&&window.remoteKey('" + k + "')", null);
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (pendingApk != null && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            File f = pendingApk;
            pendingApk = null;
            openInstaller(f);
        }
    }
}
