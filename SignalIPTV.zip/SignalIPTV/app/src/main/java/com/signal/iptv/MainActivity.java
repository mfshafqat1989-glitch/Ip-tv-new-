package com.signal.iptv;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 42;
    private static final int REQ_PLAY = 43;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private boolean tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        tv = (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");

        web = new WebView(this);
        web.setBackgroundColor(0xFF0F1A33);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        // Lets the bundled app read playlists, logins and TV guides from any server
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose playlist"), REQ_FILE);
                } catch (Exception e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/index.html");
    }

    /** Methods the app page can call. */
    public class Bridge {
        @JavascriptInterface
        public boolean isTv() {
            return tv;
        }

        @JavascriptInterface
        public void play(final String json, final int index, final boolean live, final double position, final String ua) {
            runOnUiThread(() -> {
                try {
                    PlayerActivity.items = new JSONArray(json);
                } catch (Exception e) {
                    return;
                }
                Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                i.putExtra("index", index);
                i.putExtra("live", live);
                i.putExtra("position", (long) (position * 1000));
                i.putExtra("ua", ua == null ? "" : ua);
                startActivityForResult(i, REQ_PLAY);
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            Uri[] result = (res == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (req == REQ_PLAY && data != null) {
            int idx = data.getIntExtra("index", 0);
            long pos = data.getLongExtra("position", -1);
            long dur = data.getLongExtra("duration", 0);
            web.evaluateJavascript("window.onNativeResult&&window.onNativeResult(" + idx + "," + pos + "," + dur + ")", null);
        }
    }

    private void handleBack() {
        web.evaluateJavascript("window.appBack?String(window.appBack()):'false'", v -> {
            if (v == null || !v.contains("true")) finish();
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) handleBack();
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }
}
