package com.signal.iptv;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

/** "Open Signal TV when the TV turns on": starts the app after the device finishes starting, if switched on in Settings. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a) && !"android.intent.action.QUICKBOOT_POWERON".equals(a)) return;
        if (!ctx.getSharedPreferences("signal", Context.MODE_PRIVATE).getBoolean("autostart_tv", false)) return;
        // Android 10 and newer only allow this with "Display over other apps" permission
        if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(ctx)) return;
        try {
            Intent i = new Intent(ctx, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception ignored) {
        }
    }
}
