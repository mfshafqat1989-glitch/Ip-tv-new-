package com.signal.iptv;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * "Log in with your phone": a tiny web page served on the home Wi-Fi only while the pairing screen is open.
 * The phone opens it, fills in the login, and the details are handed to the app. A random code protects it.
 */
public class PairServer extends Thread {
    public interface Listener {
        void onLogin(Map<String, String> fields);
    }

    private final ServerSocket socket;
    private final String code;
    private final Listener listener;
    private volatile boolean running = true;

    public PairServer(int port, String code, Listener listener) throws Exception {
        this.socket = new ServerSocket(port);
        this.code = code;
        this.listener = listener;
        setDaemon(true);
    }

    public int port() {
        return socket.getLocalPort();
    }

    public void shutdown() {
        running = false;
        try {
            socket.close();
        } catch (Exception ignored) {
        }
    }

    /** The phone needs the TV's address on the home network. */
    public static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    @Override
    public void run() {
        while (running) {
            try (Socket s = socket.accept()) {
                s.setSoTimeout(10000);
                handle(s);
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    private void handle(Socket s) throws Exception {
        InputStream in = s.getInputStream();
        ByteArrayOutputStream head = new ByteArrayOutputStream();
        int b, p0 = 0, p1 = 0, p2 = 0, p3 = 0;
        while (head.size() < 16384 && (b = in.read()) != -1) {
            head.write(b);
            p0 = p1; p1 = p2; p2 = p3; p3 = b;
            if (p0 == '\r' && p1 == '\n' && p2 == '\r' && p3 == '\n') break;   // end of the request headers
        }
        String[] lines = head.toString("UTF-8").split("\r\n");
        if (lines.length == 0) return;
        String[] req = lines[0].split(" ");
        if (req.length < 2) return;
        String method = req[0], path = req[1];
        int len = 0;
        for (String l : lines) {
            int c = l.indexOf(':');
            if (c > 0 && l.substring(0, c).trim().equalsIgnoreCase("Content-Length")) {
                try { len = Integer.parseInt(l.substring(c + 1).trim()); } catch (Exception ignored) { }
            }
        }
        OutputStream out = s.getOutputStream();
        if ("POST".equals(method) && path.startsWith("/add")) {
            byte[] body = new byte[Math.max(0, Math.min(len, 65536))];
            int got = 0;
            while (got < body.length) {
                int n = in.read(body, got, body.length - got);
                if (n < 0) break;
                got += n;
            }
            Map<String, String> f = parseForm(new String(body, 0, got, StandardCharsets.UTF_8));
            if (!code.equals(f.get("c"))) {
                send(out, 403, page("This code has expired", "<p>Scan the code on your TV again.</p>"));
                return;
            }
            listener.onLogin(f);
            send(out, 200, page("Sent to your TV ✓", "<p>Look at your TV: it's adding the playlist now.</p><p>You can close this page.</p>"));
            return;
        }
        String q = path.contains("?") ? path.substring(path.indexOf('?') + 1) : "";
        Map<String, String> qp = parseForm(q);
        if (qp.get("c") == null) {
            send(out, 200, page("Signal TV", "<form method='get' action='/'><label>Type the 4-digit code shown on your TV"
                    + "<input name='c' inputmode='numeric' maxlength='4' autofocus></label><button type='submit'>Next</button></form>"));
            return;
        }
        if (!code.equals(qp.get("c"))) {
            send(out, 403, page("This code has expired", "<p>Scan the code on your TV again.</p>"));
            return;
        }
        send(out, 200, page("Add a playlist to your TV",
                "<form method='post' action='/add'>"
                        + "<input type='hidden' name='c' value='" + code + "'>"
                        + "<label>Name (optional)<input name='name' placeholder='My TV'></label>"
                        + "<h2>Xtream Codes login</h2>"
                        + "<label>Server<input name='server' inputmode='url' autocapitalize='off' autocorrect='off' placeholder='http://example.com:8080'></label>"
                        + "<label>Username<input name='user' autocapitalize='off' autocorrect='off'></label>"
                        + "<label>Password<input name='pass' type='password'></label>"
                        + "<h2>Or an M3U link</h2>"
                        + "<label>Playlist link<input name='url' inputmode='url' autocapitalize='off' autocorrect='off' placeholder='http://…'></label>"
                        + "<button type='submit'>Send to TV</button></form>"));
    }

    private static Map<String, String> parseForm(String s) {
        Map<String, String> m = new HashMap<>();
        for (String pair : s.split("&")) {
            int e = pair.indexOf('=');
            if (e <= 0) continue;
            try {
                m.put(URLDecoder.decode(pair.substring(0, e), "UTF-8"), URLDecoder.decode(pair.substring(e + 1), "UTF-8"));
            } catch (Exception ignored) {
            }
        }
        return m;
    }

    private static String page(String title, String body) {
        return "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<title>Signal TV</title><style>"
                + "body{margin:0;background:#0F1A33;color:#E8EBF2;font:16px/1.4 system-ui,-apple-system,Roboto,sans-serif;padding:24px 18px}"
                + "h1{font-size:24px;margin:0 0 16px}h2{font-size:15px;color:#FCA311;margin:22px 0 6px;text-transform:uppercase;letter-spacing:.05em}"
                + "label{display:flex;flex-direction:column;gap:6px;margin:10px 0;font-weight:600}"
                + "input{font:inherit;padding:12px;border-radius:10px;border:1px solid #263763;background:#15223F;color:#E8EBF2}"
                + "button{font:inherit;font-weight:700;margin-top:22px;width:100%;padding:14px;border:0;border-radius:12px;background:#FCA311;color:#14213D}"
                + "p{color:#C9D1E3}.by{margin-top:30px;color:#8D99AE;font-size:13px}"
                + "</style></head><body><h1>" + title + "</h1>" + body + "<p class='by'>Signal TV, made by Fahad</p></body></html>";
    }

    private static void send(OutputStream out, int status, String html) throws Exception {
        byte[] b = html.getBytes(StandardCharsets.UTF_8);
        String h = "HTTP/1.1 " + status + (status == 200 ? " OK" : " Forbidden") + "\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: "
                + b.length + "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
        out.write(h.getBytes(StandardCharsets.UTF_8));
        out.write(b);
        out.flush();
    }
}
