package com.signal.iptv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.StatFs;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Movie and episode downloads. One download at a time; each one is split into parts fetched at the same
 * time when the provider allows it (much faster), and falls back to a single connection by itself when
 * the provider limits connections. Progress is saved, so downloads continue after a drop or restart.
 */
public final class Downloads {
    private static Downloads instance;

    public static synchronized Downloads get(Context c) {
        if (instance == null) instance = new Downloads(c.getApplicationContext());
        return instance;
    }

    static final class Seg {
        long start, end, done;   // bytes start..end (inclusive), done = bytes finished in this part

        boolean finished() {
            return start + done > end;
        }
    }

    static final class Item {
        String id, url, title, kind, ua, ext, status = "queued", error = "", mode = "";
        JSONObject meta = new JSONObject();
        long size = -1, done, speed, added;
        int maxConn;
        boolean ranges;
        final List<Seg> segs = new ArrayList<>();
    }

    private static final int PARTS = 4;
    private static final String UA = "Mozilla/5.0 (Linux; Android) SignalTV";
    private final Context app;
    private final File dir, stateFile;
    private final List<Item> items = new ArrayList<>();
    private final List<String> finishedTitles = new ArrayList<>();
    private Thread runner;
    private volatile Item active;
    private volatile boolean watching;
    private long lastSave;

    private Downloads(Context app) {
        this.app = app;
        File ext = app.getExternalFilesDir("downloads");
        dir = ext != null ? ext : new File(app.getFilesDir(), "downloads");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        stateFile = new File(app.getFilesDir(), "downloads.json");
        load();
        boolean resume = false;
        for (Item it : items) {
            if ("downloading".equals(it.status) || "waiting".equals(it.status)) {
                it.status = "queued";
                resume = true;
            }
        }
        if (resume) kick();
    }

    // ------------------------------------------------------------ used by the app screens and the player

    /** Starts (or re-queues) a download. Returns its id. */
    public synchronized String add(JSONObject o) {
        String url = o.optString("url", "");
        if (url.isEmpty() || url.startsWith("file:")) return "";
        String id = "d" + Integer.toHexString(url.hashCode()) + Integer.toHexString(url.length());
        Item it = find(id);
        if (it != null && !"failed".equals(it.status) && !"paused".equals(it.status)) return id;
        if (it == null) {
            it = new Item();
            it.id = id;
            it.url = url;
            it.added = System.currentTimeMillis();
            items.add(it);
        }
        it.title = o.optString("title", "Video");
        it.kind = o.optString("kind", "movie");
        it.ua = o.optString("ua", "");
        it.maxConn = o.optInt("mc", 0);
        JSONObject m = o.optJSONObject("meta");
        if (m != null) it.meta = m;
        Matcher em = Pattern.compile("\\.([a-zA-Z0-9]{2,4})(\\?|$)").matcher(url);
        it.ext = em.find() ? em.group(1).toLowerCase(Locale.ROOT) : "mp4";
        it.status = "queued";
        it.error = "";
        save(true);
        kick();
        return id;
    }

    public synchronized void pause(String id) {
        Item it = find(id);
        if (it != null && !"done".equals(it.status)) {
            it.status = "paused";
            it.speed = 0;
            save(true);
        }
    }

    public synchronized void resume(String id) {
        Item it = find(id);
        if (it != null && !"done".equals(it.status)) {
            it.status = "queued";
            it.error = "";
            save(true);
            kick();
        }
    }

    public synchronized void delete(String id) {
        Item it = find(id);
        if (it == null) return;
        it.status = "deleted";
        items.remove(it);
        //noinspection ResultOfMethodCallIgnored
        partFile(it).delete();
        //noinspection ResultOfMethodCallIgnored
        doneFile(it).delete();
        save(true);
    }

    /** While the player is open, accounts with 1 connection wait, so watching isn't cut off. */
    public void setWatching(boolean w) {
        watching = w;
        if (!w) synchronized (this) { notifyAll(); }
    }

    public synchronized String listJson() {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id).put("title", it.title).put("kind", it.kind).put("status", it.status)
                        .put("error", it.error).put("size", it.size).put("done", it.done).put("speed", it.speed)
                        .put("mode", it.mode).put("added", it.added).put("meta", it.meta).put("url", it.url);
                if ("done".equals(it.status)) o.put("file", Uri.fromFile(doneFile(it)).toString());
                a.put(o);
            }
            StatFs fs = new StatFs(dir.getPath());
            return new JSONObject().put("items", a).put("free", fs.getAvailableBytes()).toString();
        } catch (Exception e) {
            return "{\"items\":[]}";
        }
    }

    // ------------------------------------------------------------ for the notification

    public synchronized boolean busy() {
        for (Item it : items) if ("queued".equals(it.status) || "downloading".equals(it.status) || "waiting".equals(it.status)) return true;
        return false;
    }

    public synchronized String activeLine() {
        Item it = active;
        if (it == null) return busy() ? "Waiting to download…" : "";
        if ("waiting".equals(it.status)) return it.title + ": waits until you stop watching";
        String pct = it.size > 0 ? (it.done * 100 / it.size) + "%" : mb(it.done);
        return it.title + "  " + pct + (it.speed > 0 ? "  ·  " + mb(it.speed) + "/s" : "");
    }

    public synchronized int activePercent() {
        Item it = active;
        return it != null && it.size > 0 ? (int) (it.done * 100 / it.size) : -1;
    }

    public synchronized List<String> takeFinished() {
        List<String> l = new ArrayList<>(finishedTitles);
        finishedTitles.clear();
        return l;
    }

    // ------------------------------------------------------------ the download loop

    private synchronized void kick() {
        try {
            ContextCompat.startForegroundService(app, new Intent(app, DownloadService.class));
        } catch (Throwable ignored) {
            // app in the background on newer Android: downloads still run while the app is open
        }
        if (runner != null && runner.isAlive()) {
            notifyAll();
            return;
        }
        runner = new Thread(this::runLoop, "signal-downloads");
        runner.start();
    }

    private void runLoop() {
        while (true) {
            Item next = null;
            synchronized (this) {
                for (Item it : items) if ("queued".equals(it.status)) { next = it; break; }
                if (next == null) {
                    active = null;
                    runner = null;
                    return;
                }
                active = next;
            }
            try {
                download(next);
            } catch (Throwable t) {
                synchronized (this) {
                    if ("downloading".equals(next.status)) {
                        next.status = "failed";
                        next.error = message(t);
                    }
                    next.speed = 0;
                    save(true);
                }
            }
        }
    }

    private boolean running(Item it) {
        return "downloading".equals(it.status);
    }

    private void download(Item it) throws Exception {
        synchronized (this) {
            it.status = "downloading";
            it.error = "";
            save(true);
        }
        // Accounts with only 1 connection: don't download while something is playing
        while (it.maxConn == 1 && watching) {
            synchronized (this) {
                if (!"downloading".equals(it.status) && !"waiting".equals(it.status)) return;
                it.status = "waiting";
                it.speed = 0;
                wait(2000);
            }
        }
        synchronized (this) {
            if (!"downloading".equals(it.status) && !"waiting".equals(it.status)) return;
            it.status = "downloading";
        }

        if (it.segs.isEmpty()) probe(it);
        if (it.size > 0) {
            long free = new StatFs(dir.getPath()).getAvailableBytes();
            long need = it.size - it.done + 200L * 1024 * 1024;
            if (free < need) throw new Exception("Not enough space on this device (needs " + mb(it.size - it.done) + ", " + mb(free) + " free).");
        }

        if (it.ranges && it.size > 0) downloadParts(it);
        else downloadWhole(it);

        synchronized (this) {
            if (!running(it)) return;
            File part = partFile(it), done = doneFile(it);
            //noinspection ResultOfMethodCallIgnored
            done.delete();
            if (!part.renameTo(done)) throw new Exception("Couldn't save the finished file.");
            it.status = "done";
            it.speed = 0;
            it.segs.clear();
            finishedTitles.add(it.title);
            save(true);
        }
    }

    /** Asks for the first byte: tells us the size and whether the server can send parts. */
    private void probe(Item it) throws Exception {
        HttpURLConnection c = open(it, 0, 0);
        try {
            int code = c.getResponseCode();
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                Matcher m = cr == null ? null : Pattern.compile("/(\\d+)").matcher(cr);
                it.ranges = m != null && m.find();
                it.size = it.ranges ? Long.parseLong(m.group(1)) : -1;
            } else if (code == 200) {
                it.ranges = false;
                it.size = length(c);
            } else {
                throw new Exception("The server refused the download (error " + code + ").");
            }
        } finally {
            c.disconnect();
        }
        it.segs.clear();
        it.done = 0;
        if (it.ranges && it.size > 0) {
            int n = it.size > 32L * 1024 * 1024 ? PARTS : 1;
            long per = it.size / n;
            for (int i = 0; i < n; i++) {
                Seg s = new Seg();
                s.start = i * per;
                s.end = i == n - 1 ? it.size - 1 : (i + 1) * per - 1;
                it.segs.add(s);
            }
        }
    }

    private void downloadParts(final Item it) throws Exception {
        final String host = Uri.parse(it.url).getHost();
        final SharedPreferences prefs = app.getSharedPreferences("signal", Context.MODE_PRIVATE);
        int tries = 0;
        while (true) {
            boolean single = it.maxConn == 1 || prefs.getBoolean("dl_single_" + host, false);
            final int workers = single ? 1 : Math.min(PARTS, it.segs.size());
            it.mode = workers > 1 ? workers + " parts at once" : "1 connection";
            final Exception[] err = {null};
            final boolean[] stop = {false};
            final AtomicLong counter = new AtomicLong();
            try (RandomAccessFile raf = new RandomAccessFile(partFile(it), "rw")) {
                if (raf.length() < it.size) raf.setLength(it.size);
                final FileChannel ch = raf.getChannel();
                List<Thread> threads = new ArrayList<>();
                for (int w = 0; w < workers; w++) {
                    Thread t = new Thread(() -> {
                        while (true) {
                            Seg s = null;
                            synchronized (it.segs) {
                                if (stop[0]) return;
                                for (Seg x : it.segs) {
                                    if (!x.finished() && !takenSegs.contains(x)) { s = x; takenSegs.add(x); break; }
                                }
                            }
                            if (s == null) return;
                            try {
                                fetchRange(it, s, ch, counter, stop);
                            } catch (Exception e) {
                                synchronized (it.segs) {
                                    if (err[0] == null) err[0] = e;
                                    stop[0] = true;
                                }
                                return;
                            } finally {
                                synchronized (it.segs) { takenSegs.remove(s); }
                            }
                        }
                    });
                    threads.add(t);
                    t.start();
                }
                // progress and speed, once a second
                long lastBytes = counter.get(), lastT = System.currentTimeMillis();
                while (true) {
                    boolean alive = false;
                    for (Thread t : threads) {
                        t.join(250);
                        alive |= t.isAlive();
                    }
                    long now = System.currentTimeMillis();
                    synchronized (this) {
                        long sum = 0;
                        synchronized (it.segs) { for (Seg x : it.segs) sum += x.done; }
                        it.done = sum;
                        if (now - lastT >= 1000) {
                            it.speed = (counter.get() - lastBytes) * 1000 / (now - lastT);
                            lastBytes = counter.get();
                            lastT = now;
                            save(false);
                        }
                        if (!running(it)) synchronized (it.segs) { stop[0] = true; }
                    }
                    if (!alive) break;
                }
            }
            synchronized (this) { save(true); }
            if (!running(it)) return;
            boolean allDone = true;
            for (Seg x : it.segs) allDone &= x.finished();
            if (allDone) return;
            Exception e = err[0];
            if (workers > 1) {
                // The provider didn't like several connections: carry on with one (remembered for next time)
                prefs.edit().putBoolean("dl_single_" + host, true).apply();
                continue;
            }
            if (++tries > 6) throw e != null ? e : new Exception("The download kept stopping.");
            Thread.sleep(2000L * tries);
        }
    }

    private final List<Seg> takenSegs = new ArrayList<>();

    private void fetchRange(Item it, Seg s, FileChannel ch, AtomicLong counter, boolean[] stop) throws Exception {
        long from = s.start + s.done;
        HttpURLConnection c = open(it, from, s.end);
        try {
            int code = c.getResponseCode();
            if (code != 206) throw new Exception("The server refused a part (error " + code + ").");
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[256 * 1024];
                int n;
                long pos = from;
                while ((n = in.read(buf)) > 0) {
                    ByteBuffer bb = ByteBuffer.wrap(buf, 0, n);
                    while (bb.hasRemaining()) pos += ch.write(bb, pos);
                    synchronized (it.segs) {
                        s.done = pos - s.start;
                        if (stop[0]) return;
                    }
                    counter.addAndGet(n);
                    if (pos > s.end) return;
                }
            }
            if (!s.finished()) throw new Exception("The connection dropped.");
        } finally {
            c.disconnect();
        }
    }

    /** Server can't send parts: download in one go (restarts from the beginning if it drops). */
    private void downloadWhole(Item it) throws Exception {
        it.mode = "1 connection";
        int tries = 0;
        while (true) {
            HttpURLConnection c = open(it, -1, -1);
            try {
                int code = c.getResponseCode();
                if (code != 200) throw new Exception("The server refused the download (error " + code + ").");
                if (it.size <= 0) it.size = length(c);
                long got = 0, lastBytes = 0, lastT = System.currentTimeMillis();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(partFile(it))) {
                    byte[] buf = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        long now = System.currentTimeMillis();
                        synchronized (this) {
                            it.done = got;
                            if (now - lastT >= 1000) {
                                it.speed = (got - lastBytes) * 1000 / (now - lastT);
                                lastBytes = got;
                                lastT = now;
                                save(false);
                            }
                            if (!running(it)) return;
                        }
                    }
                }
                if (it.size > 0 && got < it.size) throw new Exception("The connection dropped.");
                it.size = got;
                return;
            } catch (Exception e) {
                if (!running(it) || ++tries > 4) throw e;
                Thread.sleep(3000L * tries);
            } finally {
                c.disconnect();
            }
        }
    }

    /** Opens the link, following redirects to other servers too (http and https). */
    private HttpURLConnection open(Item it, long from, long to) throws Exception {
        URL u = new URL(it.url);
        for (int hop = 0; ; hop++) {
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", it.ua == null || it.ua.isEmpty() ? UA : it.ua);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (from >= 0) c.setRequestProperty("Range", "bytes=" + from + "-" + to);
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            if (code >= 300 && code < 400 && loc != null && hop < 6) {
                c.disconnect();
                u = new URL(u, loc);
                continue;
            }
            return c;
        }
    }

    // ------------------------------------------------------------ saving the list

    private Item find(String id) {
        for (Item it : items) if (it.id.equals(id)) return it;
        return null;
    }

    private File partFile(Item it) {
        return new File(dir, it.id + ".part");
    }

    private File doneFile(Item it) {
        return new File(dir, it.id + "." + (it.ext == null ? "mp4" : it.ext));
    }

    private void save(boolean now) {
        long t = System.currentTimeMillis();
        if (!now && t - lastSave < 2000) return;
        lastSave = t;
        try {
            JSONArray a = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id).put("url", it.url).put("title", it.title).put("kind", it.kind).put("ua", it.ua)
                        .put("ext", it.ext).put("status", it.status).put("error", it.error).put("size", it.size)
                        .put("done", it.done).put("added", it.added).put("mc", it.maxConn).put("ranges", it.ranges)
                        .put("meta", it.meta).put("mode", it.mode);
                JSONArray sg = new JSONArray();
                synchronized (it.segs) {
                    for (Seg s : it.segs) sg.put(new JSONArray().put(s.start).put(s.end).put(s.done));
                }
                o.put("segs", sg);
                a.put(o);
            }
            File tmp = new File(stateFile.getPath() + ".tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(a.toString().getBytes(StandardCharsets.UTF_8));
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(stateFile);
        } catch (Exception ignored) {
        }
    }

    private void load() {
        try {
            if (!stateFile.exists()) return;
            byte[] b = new byte[(int) stateFile.length()];
            try (InputStream in = new java.io.FileInputStream(stateFile)) {
                int off = 0, n;
                while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            }
            JSONArray a = new JSONArray(new String(b, StandardCharsets.UTF_8));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.getString("id");
                it.url = o.optString("url");
                it.title = o.optString("title");
                it.kind = o.optString("kind", "movie");
                it.ua = o.optString("ua", "");
                it.ext = o.optString("ext", "mp4");
                it.status = o.optString("status", "paused");
                it.error = o.optString("error", "");
                it.size = o.optLong("size", -1);
                it.done = o.optLong("done", 0);
                it.added = o.optLong("added", 0);
                it.maxConn = o.optInt("mc", 0);
                it.ranges = o.optBoolean("ranges", false);
                it.mode = o.optString("mode", "");
                JSONObject m = o.optJSONObject("meta");
                if (m != null) it.meta = m;
                JSONArray sg = o.optJSONArray("segs");
                if (sg != null) for (int j = 0; j < sg.length(); j++) {
                    JSONArray x = sg.getJSONArray(j);
                    Seg s = new Seg();
                    s.start = x.getLong(0);
                    s.end = x.getLong(1);
                    s.done = x.getLong(2);
                    it.segs.add(s);
                }
                if ("done".equals(it.status) && !doneFile(it).exists()) continue;
                items.add(it);
            }
        } catch (Exception ignored) {
        }
    }

    /** Content-Length as a long (works on Android 5 too; files can be over 2 GB). */
    private static long length(HttpURLConnection c) {
        try {
            String v = c.getHeaderField("Content-Length");
            return v == null ? -1 : Long.parseLong(v.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private static String mb(long b) {
        if (b >= 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    private static String message(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isEmpty()) m = t.getClass().getSimpleName();
        if (t instanceof java.net.UnknownHostException) m = "No internet connection.";
        if (t instanceof java.net.SocketTimeoutException) m = "The server stopped answering.";
        return m;
    }
}
