package com.signal.iptv;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.StatFs;

import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Movie and episode downloads. One download at a time; each one is split into parts fetched at the same
 * time when the provider allows it (much faster), and falls back to a single connection by itself when
 * the provider limits connections. Progress is saved, so downloads continue after a drop or restart.
 */
public final class Downloads {
    private static Downloads instance;

    public static synchronized Downloads get(Context c) {
        if (instance == null) instance = new Downloads(c.getApplicationContext());
        return instance;
    }

    static final class Seg {
        long start, end, done;   // bytes start..end (inclusive), done = bytes finished in this part
        boolean busy;            // a connection is working on it right now

        boolean finished() {
            return start + done > end;
        }

        long left() {
            return end - (start + done) + 1;
        }
    }

    /** The provider said no to a connection (too many at once). */
    static final class Refused extends Exception {
        Refused(String m) {
            super(m);
        }
    }

    static final class Item {
        String id, url, title, kind, ua, ext, status = "queued", error = "", mode = "";
        JSONObject meta = new JSONObject();
        long size = -1, done, speed, added;
        int maxConn;
        boolean ranges;
        final List<Seg> segs = new ArrayList<>();
    }

    private static final int MAX_CONN = 8;                 // connections per download, like IDM
    private static final long MIN_SPLIT = 4L * 1024 * 1024; // don't split pieces smaller than this
    private static final String UA = "Mozilla/5.0 (Linux; Android) SignalTV";
    private final Context app;
    private final File dir, stateFile;
    private final List<Item> items = new ArrayList<>();
    private final List<String> finishedTitles = new ArrayList<>();
    private final List<Item> running = new ArrayList<>();
    private volatile boolean watching;
    private long lastSave;

    private Downloads(Context app) {
        this.app = app;
        File ext = app.getExternalFilesDir("downloads");
        dir = ext != null ? ext : new File(app.getFilesDir(), "downloads");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        stateFile = new File(app.getFilesDir(), "downloads.json");
        load();
        boolean resume = false;
        for (Item it : items) {
            if ("downloading".equals(it.status) || "waiting".equals(it.status)) {
                it.status = "queued";
                resume = true;
            }
        }
        if (resume) kick();
    }

    // ------------------------------------------------------------ used by the app screens and the player

    /** Starts (or re-queues) a download. Returns its id. */
    public synchronized String add(JSONObject o) {
        String url = o.optString("url", "");
        if (url.isEmpty() || url.startsWith("file:")) return "";
        String id = "d" + Integer.toHexString(url.hashCode()) + Integer.toHexString(url.length());
        Item it = find(id);
        if (it != null && !"failed".equals(it.status) && !"paused".equals(it.status)) return id;
        if (it == null) {
            it = new Item();
            it.id = id;
            it.url = url;
            it.added = System.currentTimeMillis();
            items.add(it);
        }
        it.title = o.optString("title", "Video");
        it.kind = o.optString("kind", "movie");
        it.ua = o.optString("ua", "");
        it.maxConn = o.optInt("mc", 0);
        JSONObject m = o.optJSONObject("meta");
        if (m != null) it.meta = m;
        Matcher em = Pattern.compile("\\.([a-zA-Z0-9]{2,4})(\\?|$)").matcher(url);
        it.ext = em.find() ? em.group(1).toLowerCase(Locale.ROOT) : "mp4";
        it.status = "queued";
        it.error = "";
        save(true);
        kick();
        return id;
    }

    public synchronized void pause(String id) {
        Item it = find(id);
        if (it != null && !"done".equals(it.status)) {
            it.status = "paused";
            it.speed = 0;
            save(true);
        }
    }

    public synchronized void resume(String id) {
        Item it = find(id);
        if (it != null && !"done".equals(it.status)) {
            it.status = "queued";
            it.error = "";
            save(true);
            kick();
        }
    }

    public synchronized void delete(String id) {
        Item it = find(id);
        if (it == null) return;
        it.status = "deleted";
        items.remove(it);
        //noinspection ResultOfMethodCallIgnored
        partFile(it).delete();
        //noinspection ResultOfMethodCallIgnored
        doneFile(it).delete();
        save(true);
    }

    /** While the player is open, accounts with 1 connection wait, so watching isn't cut off. */
    public void setWatching(boolean w) {
        watching = w;
        if (!w) synchronized (this) { notifyAll(); }
    }

    public synchronized String listJson() {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id).put("title", it.title).put("kind", it.kind).put("status", it.status)
                        .put("error", it.error).put("size", it.size).put("done", it.done).put("speed", it.speed)
                        .put("mode", it.mode).put("added", it.added).put("meta", it.meta).put("url", it.url);
                if ("done".equals(it.status)) o.put("file", Uri.fromFile(doneFile(it)).toString());
                a.put(o);
            }
            StatFs fs = new StatFs(dir.getPath());
            return new JSONObject().put("items", a).put("free", fs.getAvailableBytes()).toString();
        } catch (Exception e) {
            return "{\"items\":[]}";
        }
    }

    // ------------------------------------------------------------ for the notification

    public synchronized boolean busy() {
        for (Item it : items) if ("queued".equals(it.status) || "downloading".equals(it.status) || "waiting".equals(it.status)) return true;
        return false;
    }

    public synchronized String activeLine() {
        if (running.isEmpty()) return busy() ? "Waiting to download…" : "";
        Item it = running.get(0);
        long speed = 0;
        for (Item x : running) speed += x.speed;
        String more = running.size() > 1 ? "  (+" + (running.size() - 1) + " more)" : "";
        if ("waiting".equals(it.status)) return it.title + ": waits until you stop watching" + more;
        String pct = it.size > 0 ? (it.done * 100 / it.size) + "%" : mb(it.done);
        return it.title + "  " + pct + (speed > 0 ? "  ·  " + mb(speed) + "/s" : "") + more;
    }

    public synchronized int activePercent() {
        if (running.isEmpty()) return -1;
        Item it = running.get(0);
        return it.size > 0 ? (int) (it.done * 100 / it.size) : -1;
    }

    /** How many movies or episodes download at the same time (1 to 3). */
    public int parallelFiles() {
        return Math.max(1, Math.min(3, app.getSharedPreferences("signal", Context.MODE_PRIVATE).getInt("dl_files", 2)));
    }

    public void setParallelFiles(int n) {
        app.getSharedPreferences("signal", Context.MODE_PRIVATE).edit().putInt("dl_files", Math.max(1, Math.min(3, n))).apply();
        synchronized (this) { kick(); }
    }

    public synchronized List<String> takeFinished() {
        List<String> l = new ArrayList<>(finishedTitles);
        finishedTitles.clear();
        return l;
    }

    // ------------------------------------------------------------ the download loop

    private synchronized void kick() {
        try {
            ContextCompat.startForegroundService(app, new Intent(app, DownloadService.class));
        } catch (Throwable ignored) {
            // app in the background on newer Android: downloads still run while the app is open
        }
        notifyAll();
        int max = parallelFiles();
        for (Item it : items) {
            if (running.size() >= max) break;
            if (!"queued".equals(it.status) || running.contains(it)) continue;
            it.status = "downloading";
            running.add(it);
            final Item job = it;
            new Thread(() -> runOne(job), "signal-dl").start();
        }
    }

    private void runOne(Item it) {
        try {
            download(it);
        } catch (Throwable t) {
            synchronized (this) {
                if (running(it)) {
                    it.status = "failed";
                    it.error = message(t);
                }
            }
        } finally {
            synchronized (this) {
                it.speed = 0;
                running.remove(it);
                save(true);
                kick();
            }
        }
    }

    private boolean running(Item it) {
        return "downloading".equals(it.status);
    }

    private void download(Item it) throws Exception {
        synchronized (this) {
            it.status = "downloading";
            it.error = "";
            save(true);
        }
        // Accounts with only 1 connection: don't download while something is playing
        while (it.maxConn == 1 && watching) {
            synchronized (this) {
                if (!"downloading".equals(it.status) && !"waiting".equals(it.status)) return;
                it.status = "waiting";
                it.speed = 0;
                wait(2000);
            }
        }
        synchronized (this) {
            if (!"downloading".equals(it.status) && !"waiting".equals(it.status)) return;
            it.status = "downloading";
        }

        if (it.segs.isEmpty()) probe(it);
        if (it.size > 0) {
            long free = new StatFs(dir.getPath()).getAvailableBytes();
            long need = it.size - it.done + 200L * 1024 * 1024;
            if (free < need) throw new Exception("Not enough space on this device (needs " + mb(it.size - it.done) + ", " + mb(free) + " free).");
        }

        if (it.ranges && it.size > 0) downloadParts(it);
        else downloadWhole(it);

        synchronized (this) {
            if (!running(it)) return;
            File part = partFile(it), done = doneFile(it);
            //noinspection ResultOfMethodCallIgnored
            done.delete();
            if (!part.renameTo(done)) throw new Exception("Couldn't save the finished file.");
            it.status = "done";
            it.speed = 0;
            it.segs.clear();
            finishedTitles.add(it.title);
            save(true);
        }
    }

    /** Asks for the first byte: tells us the size and whether the server can send parts. */
    private void probe(Item it) throws Exception {
        HttpURLConnection c = open(it, 0, 0);
        try {
            int code = c.getResponseCode();
            if (code == 206) {
                String cr = c.getHeaderField("Content-Range");
                Matcher m = cr == null ? null : Pattern.compile("/(\\d+)").matcher(cr);
                it.ranges = m != null && m.find();
                it.size = it.ranges ? Long.parseLong(m.group(1)) : -1;
            } else if (code == 200) {
                it.ranges = false;
                it.size = length(c);
            } else {
                throw new Exception("The server refused the download (error " + code + ").");
            }
        } finally {
            c.disconnect();
        }
        it.segs.clear();
        it.done = 0;
        if (it.ranges && it.size > 0) {
            // One piece to start with; free connections split the biggest piece left, like IDM
            Seg s = new Seg();
            s.start = 0;
            s.end = it.size - 1;
            it.segs.add(s);
        }
    }

    /** How many connections this download may use right now. */
    private int connectionsFor(Item it, String host) {
        SharedPreferences prefs = app.getSharedPreferences("signal", Context.MODE_PRIVATE);
        int n = MAX_CONN;
        if (it.maxConn > 0) n = Math.min(n, it.maxConn - (watching ? 1 : 0));   // the account's own limit
        // A limit learned from this provider earlier today
        long when = prefs.getLong("dl_lim_t_" + host, 0);
        int learned = prefs.getInt("dl_lim_" + host, 0);
        if (learned > 0 && System.currentTimeMillis() - when < 6 * 3600_000L) n = Math.min(n, learned);
        int files;
        synchronized (this) { files = Math.max(1, running.size()); }
        if (files > 1) n = Math.max(1, n / files);   // share connections between downloads
        return Math.max(1, n);
    }

    private void learnLimit(String host, int n) {
        app.getSharedPreferences("signal", Context.MODE_PRIVATE).edit()
                .putInt("dl_lim_" + host, Math.max(1, n)).putLong("dl_lim_t_" + host, System.currentTimeMillis()).apply();
    }

    /** Picks a piece for a free connection, splitting the biggest unfinished piece if all are taken. */
    private Seg takeSeg(Item it) {
        synchronized (it.segs) {
            for (Seg x : it.segs) if (!x.finished() && !x.busy) { x.busy = true; return x; }
            Seg big = null;
            for (Seg x : it.segs) if (!x.finished() && x.busy && (big == null || x.left() > big.left())) big = x;
            if (big == null || big.left() < 2 * MIN_SPLIT) return null;
            long mid = big.start + big.done + big.left() / 2;
            Seg n = new Seg();
            n.start = mid;
            n.end = big.end;
            n.busy = true;
            big.end = mid - 1;
            it.segs.add(n);
            return n;
        }
    }

    private void downloadParts(final Item it) throws Exception {
        final String host = Uri.parse(it.url).getHost();
        int tries = 0;
        while (true) {
            final int workers = connectionsFor(it, host);
            it.mode = workers > 1 ? "up to " + workers + " connections" : "1 connection";
            final Exception[] err = {null};
            final int[] refused = {0}, live = {0}, best = {0};
            final AtomicLong counter = new AtomicLong();
            synchronized (it.segs) { for (Seg x : it.segs) x.busy = false; }
            try (RandomAccessFile raf = new RandomAccessFile(partFile(it), "rw")) {
                if (raf.length() < it.size) raf.setLength(it.size);
                final FileChannel ch = raf.getChannel();
                List<Thread> threads = new ArrayList<>();
                for (int w = 0; w < workers; w++) {
                    final int delay = w * 150;   // open connections one by one, gentler on providers
                    Thread t = new Thread(() -> {
                        try { Thread.sleep(delay); } catch (InterruptedException e) { return; }
                        int fails = 0;
                        while (running(it)) {
                            Seg s = takeSeg(it);
                            if (s == null) return;
                            try {
                                synchronized (it.segs) { live[0]++; best[0] = Math.max(best[0], live[0]); }
                                fetchRange(it, s, ch, counter);
                                fails = 0;
                            } catch (Refused e) {
                                synchronized (it.segs) { refused[0]++; if (err[0] == null) err[0] = e; }
                                return;   // this connection gives up; the others carry on and take its piece
                            } catch (Exception e) {
                                synchronized (it.segs) { if (err[0] == null || err[0] instanceof Refused) err[0] = e; }
                                if (++fails > 3) return;
                                try { Thread.sleep(1500L * fails); } catch (InterruptedException ie) { return; }
                            } finally {
                                synchronized (it.segs) { s.busy = false; live[0]--; }
                            }
                        }
                    });
                    threads.add(t);
                    t.start();
                }
                // progress and speed, once a second
                long lastBytes = 0, lastT = System.currentTimeMillis();
                while (true) {
                    boolean alive = false;
                    for (Thread t : threads) {
                        t.join(100);
                        alive |= t.isAlive();
                    }
                    long now = System.currentTimeMillis();
                    synchronized (this) {
                        long sum = 0;
                        int conns;
                        synchronized (it.segs) { for (Seg x : it.segs) sum += x.done; conns = live[0]; }
                        it.done = sum;
                        if (now - lastT >= 1000) {
                            it.speed = (counter.get() - lastBytes) * 1000 / (now - lastT);
                            lastBytes = counter.get();
                            lastT = now;
                            it.mode = conns > 1 ? conns + " connections" : conns == 1 ? "1 connection" : it.mode;
                            save(false);
                        }
                    }
                    if (!alive) break;
                }
            }
            synchronized (this) { save(true); }
            if (!running(it)) return;
            boolean allDone = true;
            synchronized (it.segs) { for (Seg x : it.segs) allDone &= x.finished(); }
            if (allDone) return;
            if (refused[0] > 0 && workers > 1) {
                // The provider allows fewer connections: remember how many worked and carry on
                learnLimit(host, Math.max(1, Math.min(workers - refused[0], best[0] - refused[0])));
                continue;
            }
            if (++tries > 6) throw err[0] != null ? err[0] : new Exception("The download kept stopping.");
            Thread.sleep(2000L * tries);
        }
    }

    private void fetchRange(Item it, Seg s, FileChannel ch, AtomicLong counter) throws Exception {
        long from, to;
        synchronized (it.segs) { from = s.start + s.done; to = s.end; }
        HttpURLConnection c = open(it, from, to);
        try {
            int code = c.getResponseCode();
            if (code == 200 || code == 403 || code == 429 || code == 456 || code == 458 || code == 503 || code == 509 || code == 551)
                throw new Refused("The provider allows fewer connections (error " + code + ").");
            if (code != 206) throw new Exception("The server refused a part (error " + code + ").");
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[256 * 1024];
                int n;
                long pos = from;
                while ((n = in.read(buf)) > 0) {
                    long end;
                    synchronized (it.segs) { end = s.end; }   // may shrink when another connection takes half
                    int use = (int) Math.min(n, end - pos + 1);
                    if (use > 0) {
                        ByteBuffer bb = ByteBuffer.wrap(buf, 0, use);
                        long p = pos;
                        while (bb.hasRemaining()) p += ch.write(bb, p);
                        pos = p;
                        counter.addAndGet(use);
                    }
                    synchronized (it.segs) { s.done = pos - s.start; }
                    if (pos > end || !running(it)) return;
                }
            }
            synchronized (it.segs) { if (!s.finished()) throw new Exception("The connection dropped."); }
        } finally {
            c.disconnect();
        }
    }

    /** Server can't send parts: download in one go (restarts from the beginning if it drops). */
    private void downloadWhole(Item it) throws Exception {
        it.mode = "1 connection";
        int tries = 0;
        while (true) {
            HttpURLConnection c = open(it, -1, -1);
            try {
                int code = c.getResponseCode();
                if (code != 200) throw new Exception("The server refused the download (error " + code + ").");
                if (it.size <= 0) it.size = length(c);
                long got = 0, lastBytes = 0, lastT = System.currentTimeMillis();
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(partFile(it))) {
                    byte[] buf = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        long now = System.currentTimeMillis();
                        synchronized (this) {
                            it.done = got;
                            if (now - lastT >= 1000) {
                                it.speed = (got - lastBytes) * 1000 / (now - lastT);
                                lastBytes = got;
                                lastT = now;
                                save(false);
                            }
                            if (!running(it)) return;
                        }
                    }
                }
                if (it.size > 0 && got < it.size) throw new Exception("The connection dropped.");
                it.size = got;
                return;
            } catch (Exception e) {
                if (!running(it) || ++tries > 4) throw e;
                Thread.sleep(3000L * tries);
            } finally {
                c.disconnect();
            }
        }
    }

    /** Opens the link, following redirects to other servers too (http and https). */
    private HttpURLConnection open(Item it, long from, long to) throws Exception {
        URL u = new URL(it.url);
        for (int hop = 0; ; hop++) {
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", it.ua == null || it.ua.isEmpty() ? UA : it.ua);
            c.setRequestProperty("Accept-Encoding", "identity");
            if (from >= 0) c.setRequestProperty("Range", "bytes=" + from + "-" + to);
            int code = c.getResponseCode();
            String loc = c.getHeaderField("Location");
            if (code >= 300 && code < 400 && loc != null && hop < 6) {
                c.disconnect();
                u = new URL(u, loc);
                continue;
            }
            return c;
        }
    }

    // ------------------------------------------------------------ saving the list

    private Item find(String id) {
        for (Item it : items) if (it.id.equals(id)) return it;
        return null;
    }

    private File partFile(Item it) {
        return new File(dir, it.id + ".part");
    }

    private File doneFile(Item it) {
        return new File(dir, it.id + "." + (it.ext == null ? "mp4" : it.ext));
    }

    private void save(boolean now) {
        long t = System.currentTimeMillis();
        if (!now && t - lastSave < 2000) return;
        lastSave = t;
        try {
            JSONArray a = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id).put("url", it.url).put("title", it.title).put("kind", it.kind).put("ua", it.ua)
                        .put("ext", it.ext).put("status", it.status).put("error", it.error).put("size", it.size)
                        .put("done", it.done).put("added", it.added).put("mc", it.maxConn).put("ranges", it.ranges)
                        .put("meta", it.meta).put("mode", it.mode);
                JSONArray sg = new JSONArray();
                synchronized (it.segs) {
                    for (Seg s : it.segs) sg.put(new JSONArray().put(s.start).put(s.end).put(s.done));
                }
                o.put("segs", sg);
                a.put(o);
            }
            File tmp = new File(stateFile.getPath() + ".tmp");
            try (OutputStream out = new FileOutputStream(tmp)) {
                out.write(a.toString().getBytes(StandardCharsets.UTF_8));
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(stateFile);
        } catch (Exception ignored) {
        }
    }

    private void load() {
        try {
            if (!stateFile.exists()) return;
            byte[] b = new byte[(int) stateFile.length()];
            try (InputStream in = new java.io.FileInputStream(stateFile)) {
                int off = 0, n;
                while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            }
            JSONArray a = new JSONArray(new String(b, StandardCharsets.UTF_8));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.getString("id");
                it.url = o.optString("url");
                it.title = o.optString("title");
                it.kind = o.optString("kind", "movie");
                it.ua = o.optString("ua", "");
                it.ext = o.optString("ext", "mp4");
                it.status = o.optString("status", "paused");
                it.error = o.optString("error", "");
                it.size = o.optLong("size", -1);
                it.done = o.optLong("done", 0);
                it.added = o.optLong("added", 0);
                it.maxConn = o.optInt("mc", 0);
                it.ranges = o.optBoolean("ranges", false);
                it.mode = o.optString("mode", "");
                JSONObject m = o.optJSONObject("meta");
                if (m != null) it.meta = m;
                JSONArray sg = o.optJSONArray("segs");
                if (sg != null) for (int j = 0; j < sg.length(); j++) {
                    JSONArray x = sg.getJSONArray(j);
                    Seg s = new Seg();
                    s.start = x.getLong(0);
                    s.end = x.getLong(1);
                    s.done = x.getLong(2);
                    it.segs.add(s);
                }
                if ("done".equals(it.status) && !doneFile(it).exists()) continue;
                items.add(it);
            }
        } catch (Exception ignored) {
        }
    }

    /** Content-Length as a long (works on Android 5 too; files can be over 2 GB). */
    private static long length(HttpURLConnection c) {
        try {
            String v = c.getHeaderField("Content-Length");
            return v == null ? -1 : Long.parseLong(v.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    private static String mb(long b) {
        if (b >= 1024L * 1024 * 1024) return String.format(Locale.US, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    private static String message(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isEmpty()) m = t.getClass().getSimpleName();
        if (t instanceof java.net.UnknownHostException) m = "No internet connection.";
        if (t instanceof java.net.SocketTimeoutException) m = "The server stopped answering.";
        return m;
    }
}
